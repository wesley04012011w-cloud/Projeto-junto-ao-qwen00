const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// SVG como asset nativo
config.resolver.assetExts = config.resolver.assetExts.filter(ext => ext !== 'svg');
config.resolver.sourceExts = [...config.resolver.sourceExts, 'svg'];

// Habilita package.json exports (obrigatório para lucide 0.468+)
config.resolver.enablePackageExports = true;

module.exports = config;
