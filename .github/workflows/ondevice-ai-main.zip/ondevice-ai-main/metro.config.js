const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// SVG como asset nativo
config.resolver.assetExts = config.resolver.assetExts.filter(ext => ext !== 'svg');
config.resolver.sourceExts = [...config.resolver.sourceExts, 'svg'];

// Habilita resolução de package.json exports (necessário para ESM)
config.resolver.enablePackageExports = true;

module.exports = config;
