import { useState, useEffect, useCallback } from "react"
import {
  View,
  Text,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Alert,
  Platform,
  KeyboardAvoidingView,
  TouchableOpacity,
  SafeAreaView,
} from "react-native"

import { useLLM, Message, LLAMA3_2_1B_SPINQUANT } from "react-native-executorch"
import { styles } from "./styles"

export default function App() {
  const [inputMessage, setInputMessage] = useState("")
  const llm = useLLM({ model: LLAMA3_2_1B_SPINQUANT })

  async function handleSendMessage() {
    if (!inputMessage.trim() || llm.isGenerating || !llm.isReady) return

    try {
      const msgToSend = inputMessage.trim()
      setInputMessage("")
      await llm.sendMessage(msgToSend)
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error)
      Alert.alert("Ops!", "Não foi possível enviar a mensagem. Tente novamente.")
    }
  }

  const renderMessage = useCallback((message: Message, index: number) => {
    const isUser = message.role === "user"
    
    return (
      <View key={index} style={[styles.messageRow, isUser ? styles.userRow : styles.aiRow]}>
        <View style={[styles.bubble, isUser ? styles.userBubble : styles.aiBubble]}>
          {!isUser && <Text style={styles.roleLabel}>Assistente</Text>}
          <Text style={styles.messageText}>{message.content}</Text>
        </View>
      </View>
    )
  }, [])

  useEffect(() => {
    if (!llm.isReady) return
    llm.configure({
      chatConfig: {
        systemPrompt: "Você é um assistente útil e prestativo. Responda sempre em português de forma clara e concisa.",
        contextWindowLength: 4096,
      },
    })
  }, [llm.isReady])

  // Tela de Carregamento do Modelo
  if (!llm.isReady) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingTitle}>Inicializando IA Local</Text>
          <Text style={styles.loadingSubtext}>Carregando Llama 3.2 no dispositivo...</Text>
          {llm.error && <Text style={styles.errorText}>Erro: {String(llm.error)}</Text>}
          <ActivityIndicator size="large" color="#818cf8" style={{ marginTop: 20 }} />
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === "ios" ? "padding" : undefined} 
        style={styles.container}
        keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
      >
        {/* Header Simples */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>OnDevice AI</Text>
          <View style={styles.statusBadge}>
            <View style={styles.statusDot} />
            <Text style={styles.statusText}>Local</Text>
          </View>
        </View>

        <ScrollView 
          style={styles.messagesContainer}
          contentContainerStyle={styles.messagesContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {llm.messageHistory.length === 0 ? (
            <View style={styles.emptyStateContainer}>
              <Text style={styles.emptyStateEmoji}>🤖</Text>
              <Text style={styles.emptyStateText}>Pronto para conversar!</Text>
              <Text style={styles.emptyStateSubtext}>Sua IA roda 100% offline neste dispositivo.</Text>
            </View>
          ) : (
            llm.messageHistory.map((message, index) => renderMessage(message, index))
          )}

          {llm.isGenerating && (
            <View style={[styles.messageRow, styles.aiRow]}>
              <View style={[styles.bubble, styles.aiBubble]}>
                <Text style={styles.roleLabel}>Assistente</Text>
                <View style={styles.typingIndicator}>
                  <Text style={styles.messageText}>{llm.response || "Pensando..."}</Text>
                </View>
              </View>
            </View>
          )}
        </ScrollView>

        {/* Área de Input Moderna */}
        <View style={styles.inputArea}>
          <View style={styles.inputWrapper}>
            <TextInput
              value={inputMessage}
              onChangeText={setInputMessage}
              placeholder="Digite sua mensagem..."
              placeholderTextColor="#9ca3af"
              style={styles.textInput}
              multiline
              maxLength={500}
              editable={!llm.isGenerating}
              returnKeyType="send"
              onSubmitEditing={handleSendMessage}
            />
            <TouchableOpacity 
              onPress={handleSendMessage}
              disabled={!inputMessage.trim() || llm.isGenerating}
              style={[
                styles.sendButton, 
                (!inputMessage.trim() || llm.isGenerating) && styles.sendButtonDisabled
              ]}
            >
              <Text style={styles.sendButtonText}>
                {llm.isGenerating ? "..." : "➤"}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}
