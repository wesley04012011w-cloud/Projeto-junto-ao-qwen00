import React, { useState, useEffect, useCallback } from "react"
import {
  View,
  Text,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Alert,
  Platform,
  KeyboardAvoidingView,
  TouchableOpacity,
  SafeAreaView,
  Modal,
} from "react-native"

import {
  Menu,
  Plus,
  Trash2,
  X,
  MessageSquare,
  Bot,
  Cpu,
  ShieldCheck,
  ArrowRight,
} from "lucide-react-native" // ⚠️ IMPORTANTE: Use lucide-react-native no mobile!

import {
  useLLM,
  Message,
  LLAMA3_2_1B_SPINQUANT,
} from "react-native-executorch"
import { styles } from "./styles"

export interface SavedChat {
  id: string
  title: string
  messages: Message[]
  updatedAt: number
}

const STORAGE_KEY = "@ondevice_ai_saved_chats"

const DEFAULT_INITIAL_CHATS: SavedChat[] = [
  {
    id: "chat-1",
    title: "Boas-vindas ao Llama 3.2",
    messages: [
      { role: "user", content: "Como funciona a IA on-device?" },
      {
        role: "assistant",
        content:
          "Olá! A IA on-device roda localmente na GPU/NPU do seu próprio dispositivo usando o PyTorch ExecuTorch. Nenhuma mensagem sua é enviada para servidores externos, garantindo privacidade total!",
      },
    ],
    updatedAt: Date.now() - 3600000,
  },
]

export default function App() {
  const [inputMessage, setInputMessage] = useState("")
  const [isDrawerOpen, setIsDrawerOpen] = useState(false)
  const [chats, setChats] = useState<SavedChat[]>(DEFAULT_INITIAL_CHATS)
  const [activeChatId, setActiveChatId] = useState<string>(DEFAULT_INITIAL_CHATS[0].id)

  const llm = useLLM({ model: LLAMA3_2_1B_SPINQUANT })

  // Carregar chats salvos (compatível com RN)
  useEffect(() => {
    const loadChats = async () => {
      try {
        const AsyncStorage = await import("@react-native-async-storage/async-storage").catch(() => null)
        if (AsyncStorage?.default) {
          const saved = await AsyncStorage.default.getItem(STORAGE_KEY)
          if (saved) {
            const parsed = JSON.parse(saved)
            if (Array.isArray(parsed) && parsed.length > 0) {
              setChats(parsed)
              setActiveChatId(parsed[0].id)
            }
          }
        }
      } catch (e) {
        console.warn("Erro ao carregar chats:", e)
      }
    }
    loadChats()
  }, [])

  // Salvar chats automaticamente
  useEffect(() => {
    const saveChats = async () => {
      try {
        const AsyncStorage = await import("@react-native-async-storage/async-storage").catch(() => null)
        if (AsyncStorage?.default) {
          await AsyncStorage.default.setItem(STORAGE_KEY, JSON.stringify(chats))
        }
      } catch (e) {
        console.warn("Erro ao salvar chats:", e)
      }
    }
    saveChats()
  }, [chats])

  useEffect(() => {
    if (!llm.isReady) return
    llm.configure({
      chatConfig: {
        systemPrompt: "Você é um assistente útil e prestativo. Responda sempre em português de forma clara e concisa.",
        contextWindowLength: 4096,
      },
    })
  }, [llm.isReady])

  const activeChat = chats.find((c) => c.id === activeChatId)

  const handleNewChat = () => {
    const newChat: SavedChat = {
      id: "chat-" + Date.now(),
      title: "Nova conversa",
      messages: [],
      updatedAt: Date.now(),
    }
    setChats((prev) => [newChat, ...prev])
    setActiveChatId(newChat.id)
    llm.clearChat?.()
    setIsDrawerOpen(false)
  }

  const handleSelectChat = (chat: SavedChat) => {
    setActiveChatId(chat.id)
    setIsDrawerOpen(false)
  }

  const handleDeleteChat = (chatId: string, e?: any) => {
    e?.stopPropagation?.()
    setChats((prev) => {
      const filtered = prev.filter((c) => c.id !== chatId)
      if (filtered.length === 0) {
        const fresh: SavedChat = {
          id: "chat-" + Date.now(),
          title: "Nova conversa",
          messages: [],
          updatedAt: Date.now(),
        }
        setActiveChatId(fresh.id)
        return [fresh]
      }
      if (activeChatId === chatId) {
        setActiveChatId(filtered[0].id)
      }
      return filtered
    })
  }

  async function handleSendMessage(customText?: string) {
    const textToSend = (customText || inputMessage).trim()
    if (!textToSend || llm.isGenerating || !llm.isReady) return

    setInputMessage("")
    const currentMessages = activeChat?.messages || []
    const isFirstMessage = currentMessages.length === 0

    const userMsg: Message = { role: "user", content: textToSend }
    const updatedMessages = [...currentMessages, userMsg]

    const newTitle = isFirstMessage
      ? textToSend.length > 28 ? textToSend.slice(0, 25) + "..." : textToSend
      : activeChat?.title || "Conversa"

    setChats((prev) =>
      prev.map((c) =>
        c.id === activeChatId
          ? { ...c, title: newTitle, messages: updatedMessages, updatedAt: Date.now() }
          : c
      )
    )

    try {
      await llm.sendMessage(textToSend)
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error)
      Alert.alert("Ops!", "Não foi possível enviar a mensagem.")
    }
  }

  useEffect(() => {
    if (llm.messageHistory.length > 0) {
      setChats((prev) =>
        prev.map((c) =>
          c.id === activeChatId
            ? { ...c, messages: llm.messageHistory, updatedAt: Date.now() }
            : c
        )
      )
    }
  }, [llm.messageHistory, activeChatId])

  const displayedMessages = activeChat?.messages?.length ? activeChat.messages : llm.messageHistory

  const renderMessage = useCallback((message: Message, index: number) => {
    const isUser = message.role === "user"
    return (
      <View key={index} style={[styles.messageRow, isUser ? styles.userRow : styles.aiRow]}>
        <View style={[styles.bubble, isUser ? styles.userBubble : styles.aiBubble]}>
          {!isUser && <Text style={styles.roleLabel}>Assistente</Text>}
          <Text style={isUser ? styles.userMessageText : styles.messageText}>{message.content}</Text>
        </View>
      </View>
    )
  }, [])

  const promptSuggestions = [
    "Dicas de otimização para React Native",
    "Como o ExecuTorch roda o Llama localmente?",
    "Escreva um hook customizado em TypeScript",
  ]

  // TELA DE CARREGAMENTO
  if (!llm.isReady) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.loadingContainer}>
          <View style={styles.loadingIconContainer}>
            <Cpu size={36} color="#ffffff" strokeWidth={1.5} />
          </View>
          <Text style={styles.loadingTitle}>Inicializando IA Local</Text>
          <Text style={styles.loadingSubtext}>
            Carregando pesos do Llama 3.2 1B e alocando memória NPU...
          </Text>

          <View style={styles.loadingCard}>
            <View style={styles.loadingStepItem}>
              <View style={styles.loadingStepDot} />
              <Text style={styles.loadingStepActiveText}>Alocação de memória NPU / GPU</Text>
            </View>
            <View style={styles.loadingStepItem}>
              <View style={styles.loadingStepDot} />
              <Text style={styles.loadingStepActiveText}>Carregamento dos pesos SpinQuant (1B)</Text>
            </View>
            <View style={styles.loadingStepItem}>
              <View style={styles.loadingStepDotPending} />
              <Text style={styles.loadingStepText}>Compilação de grafos ExecuTorch</Text>
            </View>
            <View style={styles.progressBarTrack}>
              <View style={styles.progressBarFill} />
            </View>
          </View>

          <ActivityIndicator size="large" color="#ffffff" style={{ marginTop: 24 }} />

          <View style={styles.loadingBadge}>
            <ShieldCheck size={14} color="#737373" />
            <Text style={styles.loadingBadgeText}>Inferência 100% offline • Sem internet</Text>
          </View>

          {llm.error && <Text style={styles.errorText}>Erro: {String(llm.error)}</Text>}
        </View>
      </SafeAreaView>
    )
  }

  // TELA PRINCIPAL
  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={styles.container}
        keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <TouchableOpacity onPress={() => setIsDrawerOpen(true)} style={styles.menuButton}>
              <Menu size={18} color="#ffffff" />
            </TouchableOpacity>
            <Text style={styles.headerTitle} numberOfLines={1}>
              {activeChat?.title || "OnDevice AI"}
            </Text>
          </View>
          <View style={styles.headerRight}>
            <View style={styles.statusBadge}>
              <View style={styles.statusDot} />
              <Text style={styles.statusText}>Local • Llama 3.2</Text>
            </View>
            <TouchableOpacity onPress={handleNewChat} style={styles.iconButton}>
              <Plus size={18} color="#ffffff" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Mensagens */}
        <ScrollView
          style={styles.messagesContainer}
          contentContainerStyle={styles.messagesContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {displayedMessages.length === 0 ? (
            <View style={styles.emptyStateContainer}>
              <View style={styles.emptyStateIconContainer}>
                <Bot size={34} color="#ffffff" strokeWidth={1.5} />
              </View>
              <View style={styles.emptyStateBadgeRow}>
                <View style={styles.emptyStateBadge}><Text style={styles.emptyStateBadgeText}>Llama 3.2 1B</Text></View>
                <View style={styles.emptyStateBadge}><Text style={styles.emptyStateBadgeText}>SpinQuant NPU</Text></View>
                <View style={styles.emptyStateBadge}><Text style={styles.emptyStateBadgeText}>100% Offline</Text></View>
              </View>
              <Text style={styles.emptyStateText}>Pronto para conversar!</Text>
              <Text style={styles.emptyStateSubtext}>
                Sua IA roda diretamente neste dispositivo via ExecuTorch.
              </Text>
              <View style={styles.suggestionsContainer}>
                {promptSuggestions.map((suggestion, idx) => (
                  <TouchableOpacity key={idx} onPress={() => handleSendMessage(suggestion)} style={styles.suggestionItem}>
                    <Text style={styles.suggestionText}>{suggestion}</Text>
                    <ArrowRight size={14} color="#737373" />
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          ) : (
            displayedMessages.map((message, index) => renderMessage(message, index))
          )}

          {llm.isGenerating && (
            <View style={[styles.messageRow, styles.aiRow]}>
              <View style={[styles.bubble, styles.aiBubble]}>
                <Text style={styles.roleLabel}>Assistente</Text>
                <Text style={styles.messageText}>{llm.response || "Pensando..."}</Text>
              </View>
            </View>
          )}
        </ScrollView>

        {/* Input */}
        <View style={styles.inputArea}>
          <View style={styles.inputWrapper}>
            <TextInput
              value={inputMessage}
              onChangeText={setInputMessage}
              placeholder="Pergunte algo para a IA local..."
              placeholderTextColor="#525252"
              style={styles.textInput}
              multiline
              maxLength={500}
              editable={!llm.isGenerating}
              returnKeyType="send"
              onSubmitEditing={() => handleSendMessage()}
            />
            <TouchableOpacity
              onPress={() => handleSendMessage()}
              disabled={!inputMessage.trim() || llm.isGenerating}
              style={[styles.sendButton, (!inputMessage.trim() || llm.isGenerating) && styles.sendButtonDisabled]}
            >
              <Text style={styles.sendButtonText}>{llm.isGenerating ? "..." : "➤"}</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Drawer Modal Nativo */}
        <Modal visible={isDrawerOpen} transparent animationType="slide">
          <TouchableOpacity style={styles.drawerOverlay} activeOpacity={1} onPress={() => setIsDrawerOpen(false)}>
            <View style={styles.drawer} onStartShouldSetResponder={() => true}>
              <View style={styles.drawerHeader}>
                <View style={styles.drawerTitleRow}>
                  <View style={styles.drawerIconBox}>
                    <Cpu size={15} color="#ffffff" />
                  </View>
                  <Text style={styles.drawerTitle}>Chats Salvos</Text>
                </View>
                <TouchableOpacity onPress={() => setIsDrawerOpen(false)} style={styles.closeButton}>
                  <X size={18} color="#737373" />
                </TouchableOpacity>
              </View>

              <TouchableOpacity onPress={handleNewChat} style={styles.newChatButton}>
                <Plus size={16} color="#000000" />
                <Text style={styles.newChatButtonText}>Novo Chat</Text>
              </TouchableOpacity>

              <ScrollView style={styles.chatList} showsVerticalScrollIndicator={false}>
                <Text style={styles.sectionLabel}>Histórico Local</Text>
                {chats.map((chat) => {
                  const isActive = chat.id === activeChatId
                  return (
                    <TouchableOpacity
                      key={chat.id}
                      onPress={() => handleSelectChat(chat)}
                      style={[styles.chatItem, isActive && styles.chatItemActive]}
                    >
                      <View style={styles.chatItemContent}>
                        <View style={styles.chatItemTop}>
                          <MessageSquare size={14} color={isActive ? "#ffffff" : "#737373"} style={{ marginRight: 8 }} />
                          <Text style={[styles.chatItemTitle, isActive && { color: "#ffffff" }]} numberOfLines={1}>
                            {chat.title}
                          </Text>
                        </View>
                        <Text style={styles.chatItemDate}>
                          {chat.messages.length} {chat.messages.length === 1 ? "mensagem" : "mensagens"}
                        </Text>
                      </View>
                      <TouchableOpacity onPress={(e) => handleDeleteChat(chat.id, e)} style={styles.deleteButton}>
                        <Trash2 size={13} color="#525252" />
                      </TouchableOpacity>
                    </TouchableOpacity>
                  )
                })}
              </ScrollView>

              <View style={styles.drawerFooter}>
                <View style={styles.footerRow}>
                  <Text style={styles.drawerFooterText}>Modelo:</Text>
                  <Text style={styles.footerValue}>Llama 3.2 1B</Text>
                </View>
                <View style={styles.footerRow}>
                  <Text style={styles.drawerFooterText}>Inferência:</Text>
                  <Text style={styles.footerValue}>ExecuTorch SpinQuant</Text>
                </View>
                <View style={styles.footerRow}>
                  <Text style={styles.drawerFooterText}>Privacidade:</Text>
                  <Text style={styles.footerValueGreen}>100% On-Device</Text>
                </View>
              </View>
            </View>
          </TouchableOpacity>
        </Modal>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}
