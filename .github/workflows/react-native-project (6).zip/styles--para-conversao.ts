// Compatibilidade Web <-> React Native
// Quando quiser voltar para o React Native, basta trocar as 3 linhas abaixo por:
// import { StyleSheet, Dimensions, Platform } from "react-native";

export const Dimensions = {
  get: (_dim: string) => ({
    width: typeof window !== "undefined" ? Math.min(window.innerWidth, 420) : 390,
    height: typeof window !== "undefined" ? window.innerHeight : 844,
  }),
};

export const Platform = {
  OS: "ios" as const,
  select: <T>(obj: { ios?: T; android?: T; default?: T }): T => obj.ios || obj.default as T,
};

// Conversor inteligente de estilos React Native para CSSProperties da Web
export const StyleSheet = {
  create: <T extends Record<string, any>>(stylesObj: T): T => {
    const transformed: any = {};
    for (const [key, style] of Object.entries(stylesObj)) {
      if (!style || typeof style !== "object") {
        transformed[key] = style;
        continue;
      }
      const s = { ...style };
      
      // Flexbox padrão React Native
      if (s.flexDirection && !s.display) {
        s.display = "flex";
      }
      
      // Conversão de atalhos de padding do React Native
      if (s.paddingHorizontal !== undefined) {
        s.paddingLeft = s.paddingHorizontal;
        s.paddingRight = s.paddingHorizontal;
        delete s.paddingHorizontal;
      }
      if (s.paddingVertical !== undefined) {
        s.paddingTop = s.paddingVertical;
        s.paddingBottom = s.paddingVertical;
        delete s.paddingVertical;
      }
      
      // Conversão de atalhos de margin do React Native
      if (s.marginHorizontal !== undefined) {
        s.marginLeft = s.marginHorizontal;
        s.marginRight = s.marginHorizontal;
        delete s.marginHorizontal;
      }
      if (s.marginVertical !== undefined) {
        s.marginTop = s.marginVertical;
        s.marginBottom = s.marginVertical;
        delete s.marginVertical;
      }
      
      // Bordas do React Native
      if (s.borderBottomWidth !== undefined) {
        s.borderBottomStyle = "solid";
      }
      if (s.borderTopWidth !== undefined) {
        s.borderTopStyle = "solid";
      }
      if (s.borderRightWidth !== undefined) {
        s.borderRightStyle = "solid";
      }
      if (s.borderLeftWidth !== undefined) {
        s.borderLeftStyle = "solid";
      }
      if (s.borderWidth !== undefined) {
        s.borderStyle = "solid";
      }

      // lineHeight em React Native é em pontos/px, mas no React Web DOM números são interpretados como unitless (multiplicadores de font-size)!
      if (typeof s.lineHeight === "number") {
        s.lineHeight = `${s.lineHeight}px`;
      }

      // No Web, containers com maxWidth precisam de width: fit-content para não encolherem ao min-content (1 caractere)
      if (s.maxWidth && !s.width) {
        s.width = "fit-content";
      }
      
      transformed[key] = s;
    }
    return transformed as T;
  },
};

export const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#000000", // AMOLED Black
  },
  container: {
    flex: 1,
    backgroundColor: "#000000",
    position: "relative",
    overflow: "hidden",
  },
  
  // Header AMOLED & Floating Controls (Substitui a top bar estática para não ocupar espaço)
  floatingHeader: {
    position: "absolute",
    top: 12,
    left: 14,
    right: 14,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    zIndex: 20,
    pointerEvents: "box-none",
  },
  floatingButton: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: "rgba(18, 18, 18, 0.8)",
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.12)",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 4,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#171717",
    backgroundColor: "rgba(0, 0, 0, 0.82)",
    zIndex: 10,
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  menuButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    backgroundColor: "#0d0d0d",
    borderWidth: 1,
    borderColor: "#262626",
    justifyContent: "center",
    alignItems: "center",
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#ffffff",
    letterSpacing: -0.3,
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  statusBadge: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#0d0d0d",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "#262626",
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: "#ffffff",
    marginRight: 6,
  },
  statusText: {
    fontSize: 11,
    fontWeight: "600",
    color: "#a3a3a3",
  },
  iconButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    backgroundColor: "#0d0d0d",
    borderWidth: 1,
    borderColor: "#262626",
    justifyContent: "center",
    alignItems: "center",
  },

  // Messages
  messagesContainer: {
    flex: 1,
    backgroundColor: "transparent",
    zIndex: 2,
  },
  messagesContent: {
    paddingHorizontal: 16,
    paddingTop: 56,
    paddingBottom: 16,
    flexGrow: 1,
  },
  messageRow: {
    width: "100%",
    marginBottom: 12,
    display: "flex",
    flexDirection: "column",
  },
  userRow: {
    alignItems: "flex-end",
  },
  aiRow: {
    alignItems: "flex-start",
  },
  bubble: {
    paddingHorizontal: 15,
    paddingVertical: 11,
    borderRadius: 18,
    maxWidth: "85%",
  },
  userBubble: {
    backgroundColor: "#2f2f2f", // Cinza estilo ChatGPT (ao invés de branco)
    borderBottomRightRadius: 4,
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.08)",
  },
  aiBubble: {
    backgroundColor: "#212121", // Cinza escuro estilo ChatGPT (ao invés de preto)
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    borderColor: "#303030",
  },
  roleLabel: {
    fontSize: 11,
    fontWeight: "700",
    color: "#9ca3af",
    marginBottom: 4,
    textTransform: "uppercase",
    letterSpacing: 0.6,
  },
  messageText: {
    fontSize: 15,
    color: "#ececec",
    lineHeight: 22,
  },
  userMessageText: {
    fontSize: 15,
    color: "#f4f4f4", // Texto claro para a bolha cinza ChatGPT
    lineHeight: 22,
    fontWeight: "400",
  },

  // Métricas de Inferência (Timer, Contador de Tokens, Velocidade tok/s)
  metricsContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
    paddingTop: 6,
    borderTopWidth: 1,
    borderTopColor: "rgba(255, 255, 255, 0.08)",
    gap: 6,
    flexWrap: "wrap",
  },
  metricsBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  metricsIcon: {
    fontSize: 10,
    color: "#737373",
  },
  metricsText: {
    fontSize: 11,
    color: "#8a8a8a",
  },
  metricsSpeedText: {
    fontSize: 11,
    color: "#4ade80",
    fontWeight: "600",
  },
  metricsDivider: {
    width: 3,
    height: 3,
    borderRadius: 1.5,
    backgroundColor: "#333333",
  },

  // Empty State AMOLED
  emptyStateContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 60,
    paddingHorizontal: 24,
  },
  emptyStateIconContainer: {
    width: 68,
    height: 68,
    borderRadius: 22,
    backgroundColor: "#0d0d0d",
    borderWidth: 1,
    borderColor: "#262626",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 18,
  },
  emptyStateBadgeRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 14,
  },
  emptyStateBadge: {
    backgroundColor: "#0d0d0d",
    borderWidth: 1,
    borderColor: "#262626",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
  },
  emptyStateBadgeText: {
    fontSize: 11,
    color: "#a3a3a3",
    fontWeight: "600",
  },
  emptyStateText: {
    fontSize: 20,
    fontWeight: "700",
    color: "#ffffff",
    marginBottom: 8,
    textAlign: "center",
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: "#737373",
    textAlign: "center",
    lineHeight: 22,
    maxWidth: 290,
  },
  suggestionsContainer: {
    width: "100%",
    maxWidth: 340,
    marginTop: 26,
    gap: 8,
  },
  suggestionItem: {
    backgroundColor: "#0a0a0a",
    borderWidth: 1,
    borderColor: "#1e1e1e",
    borderRadius: 12,
    paddingVertical: 11,
    paddingHorizontal: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  suggestionText: {
    fontSize: 13,
    color: "#d4d4d4",
    flex: 1,
  },

  // Input Area AMOLED
  inputArea: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: "rgba(0, 0, 0, 0.85)",
    borderTopWidth: 1,
    borderTopColor: "#171717",
    zIndex: 10,
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "flex-end",
    backgroundColor: "#0a0a0a",
    borderRadius: 24,
    paddingLeft: 16,
    paddingRight: 6,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: "#262626",
  },
  textInput: {
    flex: 1,
    minHeight: 38,
    maxHeight: 110,
    color: "#ffffff",
    fontSize: 15,
    paddingTop: 8,
    paddingBottom: 8,
  },
  sendButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "#ffffff",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 2,
  },
  sendButtonDisabled: {
    backgroundColor: "#1c1c1e",
    opacity: 0.5,
  },
  sendButtonText: {
    color: "#000000",
    fontSize: 15,
    fontWeight: "bold",
    marginLeft: 1,
  },

  // Loading Screen AMOLED com Background Animado
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
    backgroundColor: "#000000",
    position: "relative",
    overflow: "hidden",
  },
  loadingContent: {
    width: "100%",
    maxWidth: 340,
    alignItems: "center",
    zIndex: 2,
  },
  loadingBadge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: "rgba(255, 255, 255, 0.04)",
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.1)",
    marginBottom: 28,
  },
  loadingBadgeDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: "#34d399",
    marginRight: 8,
  },
  loadingBadgeText: {
    fontSize: 11,
    fontWeight: "700",
    color: "#a1a1aa",
    letterSpacing: 1.2,
    textTransform: "uppercase",
  },
  counterWrapper: {
    flexDirection: "row",
    alignItems: "baseline",
    justifyContent: "center",
    marginBottom: 8,
  },
  counterNumber: {
    fontSize: 72,
    fontWeight: "800",
    color: "#ffffff",
    letterSpacing: -3,
    lineHeight: 76,
  },
  counterPercent: {
    fontSize: 28,
    fontWeight: "500",
    color: "#71717a",
    marginLeft: 4,
  },
  loadingTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#ffffff",
    marginBottom: 8,
    textAlign: "center",
    letterSpacing: -0.4,
  },
  loadingSubtext: {
    fontSize: 13,
    color: "#a1a1aa",
    textAlign: "center",
    maxWidth: 300,
    lineHeight: 20,
    marginBottom: 28,
  },
  progressBarContainer: {
    width: "100%",
    gap: 8,
    marginBottom: 24,
  },
  progressBarTrack: {
    width: "100%",
    height: 6,
    backgroundColor: "#18181b",
    borderRadius: 3,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "#27272a",
  },
  progressBarFill: {
    height: "100%",
    backgroundColor: "#ffffff",
    borderRadius: 3,
  },
  progressMetaRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  progressMetaLabel: {
    fontSize: 11,
    color: "#71717a",
    fontWeight: "600",
    letterSpacing: 0.5,
    textTransform: "uppercase",
  },
  progressMetaValue: {
    fontSize: 11,
    color: "#e4e4e7",
    fontWeight: "600",
    fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace",
  },
  loadingCard: {
    width: "100%",
    backgroundColor: "rgba(18, 18, 20, 0.75)",
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.08)",
    borderRadius: 16,
    padding: 16,
    gap: 12,
  },
  loadingStepItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  loadingStepLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    flex: 1,
  },
  loadingStepDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: "#ffffff",
  },
  loadingStepDotPending: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: "#3f3f46",
  },
  loadingStepDotDone: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: "#34d399",
  },
  loadingStepText: {
    fontSize: 12,
    color: "#71717a",
  },
  loadingStepActiveText: {
    fontSize: 12,
    color: "#ffffff",
    fontWeight: "600",
  },
  loadingStepDoneText: {
    fontSize: 12,
    color: "#a1a1aa",
  },
  loadingStepTag: {
    fontSize: 10,
    fontWeight: "700",
    color: "#71717a",
    letterSpacing: 0.5,
    textTransform: "uppercase",
  },
  loadingStepTagActive: {
    fontSize: 10,
    fontWeight: "700",
    color: "#34d399",
    letterSpacing: 0.5,
    textTransform: "uppercase",
  },
  loadingFooterTag: {
    marginTop: 24,
    paddingHorizontal: 12,
    paddingVertical: 5,
  },
  loadingFooterText: {
    fontSize: 11,
    color: "#52525b",
    letterSpacing: 0.3,
    textAlign: "center",
  },
  errorText: {
    fontSize: 13,
    color: "#f87171",
    marginTop: 14,
    textAlign: "center",
  },

  // Drawer Styles (DENTRO DO STYLESHEET!)
  drawerOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.85)",
  },
  drawer: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    width: 310,
    maxWidth: "85%",
    backgroundColor: "#000000",
    borderRightWidth: 1,
    borderRightColor: "#262626",
    padding: 16,
  },
  drawerHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#171717",
  },
  drawerTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  drawerIconBox: {
    width: 28,
    height: 28,
    borderRadius: 8,
    backgroundColor: "#141414",
    borderWidth: 1,
    borderColor: "#262626",
    justifyContent: "center",
    alignItems: "center",
  },
  drawerTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#ffffff",
  },
  closeButton: {
    padding: 6,
    borderRadius: 8,
  },
  newChatButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#ffffff",
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginBottom: 10,
    gap: 8,
  },
  newChatButtonText: {
    color: "#000000",
    fontSize: 14,
    fontWeight: "700",
  },
  drawerModelsButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#121214",
    borderWidth: 1,
    borderColor: "#27272a",
    borderRadius: 12,
    paddingVertical: 11,
    paddingHorizontal: 16,
    marginBottom: 16,
    gap: 8,
  },
  drawerModelsButtonText: {
    color: "#e4e4e7",
    fontSize: 13,
    fontWeight: "600",
  },
  sectionLabel: {
    fontSize: 11,
    fontWeight: "700",
    color: "#525252",
    textTransform: "uppercase",
    letterSpacing: 1,
    paddingHorizontal: 4,
    marginBottom: 8,
  },
  chatList: {
    flex: 1,
  },
  chatItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 12,
    marginBottom: 6,
    backgroundColor: "#0a0a0a",
    borderWidth: 1,
    borderColor: "#171717",
  },
  chatItemActive: {
    backgroundColor: "#141414",
    borderColor: "#333333",
  },
  chatItemContent: {
    flex: 1,
    marginRight: 8,
  },
  chatItemTop: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 4,
  },
  chatItemTitle: {
    fontSize: 13,
    fontWeight: "600",
    color: "#a3a3a3",
    flex: 1,
  },
  chatItemDate: {
    fontSize: 11,
    color: "#525252",
    marginLeft: 22,
  },
  deleteButton: {
    padding: 6,
    borderRadius: 6,
  },
  drawerFooter: {
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: "#171717",
    marginTop: "auto",
    gap: 6,
  },
  footerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  drawerFooterText: {
    fontSize: 11,
    color: "#737373",
  },
  footerValue: {
    fontSize: 11,
    color: "#ffffff",
    fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace",
  },
  footerValueGreen: {
    fontSize: 11,
    color: "#34d399",
    fontWeight: "600",
  },
  // Ready Screen Styles
  readyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
    backgroundColor: "#000000",
  },
  readyIconContainer: {
    width: 88,
    height: 88,
    borderRadius: 28,
    backgroundColor: "#0d0d0d",
    borderWidth: 1,
    borderColor: "#262626",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 24,
  },
  readyTitle: {
    fontSize: 28,
    fontWeight: "800",
    color: "#ffffff",
    marginBottom: 12,
    letterSpacing: -0.5,
  },
  readySubtext: {
    fontSize: 15,
    color: "#a3a3a3",
    textAlign: "center",
    lineHeight: 22,
    maxWidth: 300,
    marginBottom: 32,
  },
  readyFeatures: {
    width: "100%",
    maxWidth: 320,
    gap: 12,
    marginBottom: 32,
  },
  featureItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    backgroundColor: "#0d0d0d",
    borderWidth: 1,
    borderColor: "#262626",
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  featureText: {
    fontSize: 14,
    color: "#e5e5e5",
    fontWeight: "500",
  },
  startButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#ffffff",
    borderRadius: 16,
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 10,
    width: "100%",
    maxWidth: 320,
    marginBottom: 16,
  },
  startButtonText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#000000",
  },
  readyDisclaimer: {
    fontSize: 12,
    color: "#737373",
    textAlign: "center",
    lineHeight: 18,
    maxWidth: 280,
  },

  // ==========================================
  // MODELOS SCREEN STYLES (ESBOÇO REACT NATIVE)
  // ==========================================
  modelsContainer: {
    flex: 1,
    height: "100%",
    minHeight: 0,
    width: "100%",
    backgroundColor: "#000000",
    position: "relative",
    display: "flex",
    flexDirection: "column",
    overflow: "hidden",
  },
  modelsHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#171717",
    backgroundColor: "#000000",
    zIndex: 10,
  },
  modelsHeaderTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#ffffff",
    letterSpacing: -0.3,
  },
  modelsHeaderSubtitle: {
    fontSize: 11,
    color: "#71717a",
    marginTop: 2,
  },
  modelsCloseBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: "#141414",
    borderWidth: 1,
    borderColor: "#262626",
    justifyContent: "center",
    alignItems: "center",
  },
  modelsCloseBtnText: {
    fontSize: 16,
    color: "#a1a1aa",
    fontWeight: "bold",
  },
  modelsStatsBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: "#080808",
    borderBottomWidth: 1,
    borderBottomColor: "#171717",
    zIndex: 5,
  },
  modelsStatItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  modelsStatLabel: {
    fontSize: 11,
    color: "#71717a",
  },
  modelsStatValue: {
    fontSize: 11,
    color: "#e4e4e7",
    fontWeight: "600",
    fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace",
  },
  modelsList: {
    flex: 1,
    height: "100%",
    minHeight: 0,
    width: "100%",
    zIndex: 2,
  },
  modelsListContent: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 120, // Espaço extra generoso para rolar livremente para cima e para baixo
    flexGrow: 1,
  },
  modelsSectionHeader: {
    fontSize: 11,
    fontWeight: "700",
    color: "#525252",
    textTransform: "uppercase",
    letterSpacing: 1,
    marginBottom: 10,
    marginTop: 4,
  },
  modelCard: {
    backgroundColor: "#0a0a0c",
    borderWidth: 1,
    borderColor: "#1e1e24",
    borderRadius: 14,
    padding: 14,
    marginBottom: 12,
  },
  modelCardActive: {
    borderColor: "rgba(52, 211, 153, 0.4)",
    backgroundColor: "#08100c",
  },
  modelCardTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 6,
  },
  modelCardTitleRow: {
    flex: 1,
    marginRight: 8,
  },
  modelCardName: {
    fontSize: 14,
    fontWeight: "700",
    color: "#ffffff",
    marginBottom: 2,
  },
  modelCardTag: {
    fontSize: 11,
    color: "#71717a",
  },
  modelStatusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    alignSelf: "flex-start",
  },
  badgeAvailable: {
    backgroundColor: "#18181b",
    borderWidth: 1,
    borderColor: "#27272a",
  },
  badgeDownloaded: {
    backgroundColor: "rgba(59, 130, 246, 0.12)",
    borderWidth: 1,
    borderColor: "rgba(59, 130, 246, 0.3)",
  },
  badgeLoaded: {
    backgroundColor: "rgba(52, 211, 153, 0.15)",
    borderWidth: 1,
    borderColor: "rgba(52, 211, 153, 0.4)",
  },
  modelStatusText: {
    fontSize: 10,
    fontWeight: "700",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  modelCardDesc: {
    fontSize: 12,
    color: "#a1a1aa",
    lineHeight: 17,
    marginTop: 4,
    marginBottom: 10,
  },
  modelCardMetaRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 12,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: "rgba(255, 255, 255, 0.05)",
  },
  modelMetaText: {
    fontSize: 11,
    color: "#71717a",
  },
  modelMetaValue: {
    color: "#d4d4d8",
    fontWeight: "600",
  },
  modelCardActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  btnDownload: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#ffffff",
    borderRadius: 10,
    paddingVertical: 9,
    paddingHorizontal: 12,
    gap: 6,
  },
  btnDownloadText: {
    color: "#000000",
    fontSize: 12,
    fontWeight: "700",
  },
  btnLoad: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#1e293b",
    borderWidth: 1,
    borderColor: "#3b82f6",
    borderRadius: 10,
    paddingVertical: 9,
    paddingHorizontal: 12,
    gap: 6,
  },
  btnLoadText: {
    color: "#60a5fa",
    fontSize: 12,
    fontWeight: "700",
  },
  btnUnload: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#271212",
    borderWidth: 1,
    borderColor: "#ef4444",
    borderRadius: 10,
    paddingVertical: 9,
    paddingHorizontal: 12,
    gap: 6,
  },
  btnUnloadText: {
    color: "#f87171",
    fontSize: 12,
    fontWeight: "700",
  },
  btnDeleteModel: {
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 10,
    backgroundColor: "#18181b",
    borderWidth: 1,
    borderColor: "#27272a",
    justifyContent: "center",
    alignItems: "center",
  },
  btnDeleteModelText: {
    color: "#71717a",
    fontSize: 12,
  },

  // Botão Flutuante de Importar Modelos (Canto Inferior Direito)
  importFab: {
    position: "absolute",
    bottom: 22,
    right: 18,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#ffffff",
    borderRadius: 24,
    paddingVertical: 12,
    paddingHorizontal: 16,
    gap: 8,
    shadowColor: "#000000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    zIndex: 40,
    elevation: 6,
  },
  importFabIcon: {
    fontSize: 16,
    color: "#000000",
    fontWeight: "bold",
  },
  importFabText: {
    color: "#000000",
    fontSize: 13,
    fontWeight: "700",
  },
});
