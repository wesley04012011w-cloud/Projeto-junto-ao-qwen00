const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Habilita resolução de package.json exports
config.resolver.unstable_enablePackageExports = true;

module.exports = config;
