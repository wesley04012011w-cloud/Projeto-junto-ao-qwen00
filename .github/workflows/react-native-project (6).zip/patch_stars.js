const fs = require('fs');
let content = fs.readFileSync('App.tsx', 'utf8');

const fallingStarsReplacement = `
function Star({ star }: { star: any }) {
  const translateY = useRef(new Animated.Value(-50)).current;
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(translateY, {
          toValue: 900,
          duration: star.duration,
          delay: star.delay,
          easing: Easing.linear,
          useNativeDriver: true,
        }),
        Animated.timing(translateY, { toValue: -50, duration: 0, useNativeDriver: true })
      ])
    ).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 0.6, duration: star.duration * 0.2, delay: star.delay, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.6, duration: star.duration * 0.6, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0, duration: star.duration * 0.2, useNativeDriver: true })
      ])
    ).start();
  }, []);

  return (
    <Animated.View
      style={{
        position: 'absolute',
        left: \`\${star.left}%\`,
        width: star.size,
        height: star.size,
        borderRadius: star.size / 2,
        backgroundColor: '#ffffff',
        shadowColor: '#ffffff',
        shadowOpacity: 0.8,
        shadowRadius: 3,
        opacity,
        transform: [{ translateY }]
      }}
    />
  );
}

function FallingStarsBackground() {
  return (
    <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 0 }} pointerEvents="none">
      {FALLING_STARS_DATA.map((star) => (
        <Star key={star.id} star={star} />
      ))}
    </View>
  );
}
`;

// Replace the old FallingStarsBackground implementation
const startIdx = content.indexOf('function FallingStarsBackground() {');
const mainAppIdx = content.indexOf('function MainApp() {');

if (startIdx !== -1 && mainAppIdx !== -1) {
  content = content.substring(0, startIdx) + fallingStarsReplacement + '\n' + content.substring(mainAppIdx);
  fs.writeFileSync('App.tsx', content);
  console.log("Patched FallingStarsBackground");
} else {
  console.error("Could not find boundaries");
}
