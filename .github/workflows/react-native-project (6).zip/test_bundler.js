const { execSync } = require('child_process');
try {
  execSync('npx expo export:embed --platform android --dev false --entry-file App.tsx --bundle-output /tmp/test.js --assets-dest /tmp/', { stdio: 'inherit' });
  console.log('Bundle success!');
} catch (e) {
  console.log('Bundle failed!');
}
