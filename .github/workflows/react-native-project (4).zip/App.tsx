
import React, { Component, useState, useEffect, useCallback, useRef } from "react";
import { View, Text, TouchableOpacity, ScrollView, TextInput, SafeAreaView, KeyboardAvoidingView, ActivityIndicator, Modal, Alert, Platform, Animated, Easing } from "react-native";
import { styles } from "./styles";
import Markdown from "react-native-markdown-display";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useLLM, Message, LLAMA3_2_1B_SPINQUANT, LLAMA3_2_3B_SPINQUANT, QWEN2_5_1_5B_QUANTIZED, PHI_4_MINI_4B_QUANTIZED } from "react-native-executorch";
import { registerRootComponent } from 'expo';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';


export interface GenerationMetrics {
  durationMs: number;
  tokenCount: number;
  tokensPerSecond: number;
}

// Em react-native-executorch, o type Message eh { role: 'system'|'user'|'assistant', content: string }. 
// Nós vamos estender isso para o nosso app
export interface AppMessage extends Message {
  metrics?: GenerationMetrics;
}

export interface SavedChat {
  id: string;
  title: string;
  messages: AppMessage[];
  updatedAt: number;
}

export type ModelStatus = "available" | "downloading" | "downloaded" | "loaded";

export interface AIModelItem {
  id: string;
  name: string;
  parameters: string;
  format: string;
  size: string;
  contextLength: string;
  description: string;
  status: ModelStatus;
  libModel: any;
}

export const INITIAL_MODELS: AIModelItem[] = [
  {
    id: "llama-3.2-1b",
    name: "Llama 3.2 1B Instruct",
    parameters: "1.23B",
    format: "ExecuTorch SpinQuant",
    size: "890 MB",
    contextLength: "2048 ctx",
    description: "Modelo ultraleve e veloz, ideal para conversas diretas e assistência diária com consumo mínimo de memória RAM.",
    status: "available",
    libModel: LLAMA3_2_1B_SPINQUANT,
  },
  {
    id: "llama-3.2-3b",
    name: "Llama 3.2 3B Instruct",
    parameters: "3.21B",
    format: "ExecuTorch 4-bit",
    size: "2.1 GB",
    contextLength: "4096 ctx",
    description: "Excelente equilíbrio entre raciocínio complexo, síntese e velocidade.",
    status: "available",
    libModel: LLAMA3_2_3B_SPINQUANT,
  },
  {
    id: "qwen-2.5-1.5b",
    name: "Qwen 2.5 1.5B Chat",
    parameters: "1.54B",
    format: "ExecuTorch Q4",
    size: "1.1 GB",
    contextLength: "8192 ctx",
    description: "Destaca-se em multilíngue, raciocínio lógico e instruções estruturadas em português.",
    status: "available",
    libModel: QWEN2_5_1_5B_QUANTIZED,
  },
  {
    id: "phi-4-mini",
    name: "Phi-4 Mini 4B",
    parameters: "3.8B",
    format: "ExecuTorch INT4",
    size: "2.4 GB",
    contextLength: "4096 ctx",
    description: "Modelo compacto de alta precisão da Microsoft, forte em raciocínio analítico.",
    status: "available",
    libModel: PHI_4_MINI_4B_QUANTIZED,
  },
];

const STORAGE_KEY = "@ondevice_ai_saved_chats";
const MODEL_LOADED_KEY = "@ondevice_ai_model_loaded";

const DEFAULT_INITIAL_CHATS: SavedChat[] = [
  {
    id: "chat-1",
    title: "Nova conversa",
    messages: [],
    updatedAt: Date.now(),
  },
];

const loadingMessages = [
  "Alocando memória unificada...",
  "Carregando pesos quantizados para a RAM...",
  "Otimizando tensores para NPU/GPU local...",
  "Quase lá! Preparando ambiente de inferência...",
];

class ErrorBoundary extends Component<{children: React.ReactNode}, {hasError: boolean, error: any}> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("ErrorBoundary capturou:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.readyContainer}>
            <Text style={{ fontSize: 44, marginBottom: 16 }}>⚠️</Text>
            <Text style={styles.readyTitle}>Ocorreu um erro</Text>
            <Text style={[styles.readySubtext, { color: "#ef4444" }]}>
              {String(this.state.error?.message || this.state.error)}
            </Text>
            <TouchableOpacity
              onPress={() => this.setState({ hasError: false, error: null })}
              style={[styles.startButton, { marginTop: 20 }]}
            >
              <Text style={styles.startButtonText}>Reiniciar App</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      );
    }
    return this.props.children;
  }
}

// Estrelinhas brancas animadas via React Native Animated
const FALLING_STARS_DATA = Array.from({ length: 25 }, (_, i) => ({
  id: i,
  left: Math.random() * 100,
  size: 1.5 + Math.random() * 2,
  duration: 6000 + Math.random() * 6000,
  delay: Math.random() * 4000,
}));

function FallingStarsBackground() {
  return (
    <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 0 }} pointerEvents="none">
      {FALLING_STARS_DATA.map((star) => {
        const translateY = useRef(new Animated.Value(-50)).current;
        const opacity = useRef(new Animated.Value(0)).current;

        useEffect(() => {
          Animated.loop(
            Animated.sequence([
              Animated.timing(translateY, {
                toValue: 900,
                duration: star.duration,
                delay: star.delay,
                easing: Easing.linear,
                useNativeDriver: true,
              }),
              Animated.timing(translateY, { toValue: -50, duration: 0, useNativeDriver: true })
            ])
          ).start();

          Animated.loop(
            Animated.sequence([
              Animated.timing(opacity, { toValue: 0.6, duration: star.duration * 0.2, delay: star.delay, useNativeDriver: true }),
              Animated.timing(opacity, { toValue: 0.6, duration: star.duration * 0.6, useNativeDriver: true }),
              Animated.timing(opacity, { toValue: 0, duration: star.duration * 0.2, useNativeDriver: true })
            ])
          ).start();
        }, []);

        return (
          <Animated.View
            key={star.id}
            style={{
              position: 'absolute',
              left: `${star.left}%`,
              width: star.size,
              height: star.size,
              borderRadius: star.size / 2,
              backgroundColor: '#ffffff',
              shadowColor: '#ffffff',
              shadowOpacity: 0.8,
              shadowRadius: 3,
              opacity,
              transform: [{ translateY }]
            }}
          />
        );
      })}
    </View>
  );
}

function MainApp() {
  const [appPhase, setAppPhase] = useState<"booting" | "running">("booting");
  const [inputMessage, setInputMessage] = useState("");
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isModelsModalOpen, setIsModelsModalOpen] = useState(false);
  const [models, setModels] = useState<AIModelItem[]>(INITIAL_MODELS);
  const [chats, setChats] = useState<SavedChat[]>(DEFAULT_INITIAL_CHATS);
  const [activeChatId, setActiveChatId] = useState<string>(DEFAULT_INITIAL_CHATS[0].id);
  
  const [shouldLoadModel, setShouldLoadModel] = useState(false);
  const [activeModel, setActiveModel] = useState<any>(LLAMA3_2_1B_SPINQUANT);

  // useLLM is native and handles everything. We pass preventLoad to not load until requested.
  const llm = useLLM({
    model: activeModel,
    preventLoad: !shouldLoadModel,
  });

  useEffect(() => {
    const timer = setTimeout(() => {
      setAppPhase("running");
      setIsModelsModalOpen(true);
    }, 1200);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const loadData = async () => {
      try {
        const saved = await AsyncStorage.getItem(STORAGE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setChats(parsed);
            setActiveChatId(parsed[0].id);
          }
        }
        const modelLoaded = await AsyncStorage.getItem(MODEL_LOADED_KEY);
        if (modelLoaded === "true") {
          // If we had a model loaded, load it. But wait, which one?
          // For simplicity, we just load the default.
          // setShouldLoadModel(true);
          // setIsModelsModalOpen(false);
        }
      } catch (e) {
        console.warn("Erro ao carregar dados:", e);
      }
    };
    loadData();
  }, []);

  useEffect(() => {
    try {
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(chats));
    } catch (e) {
      console.warn("Erro ao salvar chats:", e);
    }
  }, [chats]);

  const handleDownloadModel = (id: string) => {
    // Para simplificar a UX, vamos deixar o próprio `useLLM` baixar ao carregar, 
    // mas atualizamos a interface para dar feedback.
    Alert.alert("Aviso", "O modelo será baixado automaticamente quando você clicar em 'Carregar na RAM'.");
  };

  const handleLoadModel = (id: string) => {
    const modelToLoad = models.find(m => m.id === id);
    if (!modelToLoad) return;

    setActiveModel(modelToLoad.libModel);
    
    setModels((prev) =>
      prev.map((m) => {
        if (m.id === id) return { ...m, status: "loaded" };
        if (m.status === "loaded") return { ...m, status: "available" };
        return m;
      })
    );
    setShouldLoadModel(false); // reset state to trigger reload
    setTimeout(() => {
      setShouldLoadModel(true);
      setIsModelsModalOpen(false);
      AsyncStorage.setItem(MODEL_LOADED_KEY, "true");
    }, 100);
  };

  const handleUnloadModel = (id: string) => {
    setModels((prev) =>
      prev.map((m) => (m.id === id ? { ...m, status: "available" } : m))
    );
    setShouldLoadModel(false);
    AsyncStorage.setItem(MODEL_LOADED_KEY, "false");
  };

  const activeChat = chats.find((c) => c.id === activeChatId);

  const handleNewChat = () => {
    const newChat: SavedChat = {
      id: "chat-" + Date.now(),
      title: "Nova conversa",
      messages: [],
      updatedAt: Date.now(),
    };
    setChats((prev) => [newChat, ...prev]);
    setActiveChatId(newChat.id);
    setIsDrawerOpen(false);
  };

  const handleSelectChat = (chat: SavedChat) => {
    setActiveChatId(chat.id);
    setIsDrawerOpen(false);
  };

  const handleDeleteChat = (chatId: string) => {
    setChats((prev) => {
      const filtered = prev.filter((c) => c.id !== chatId);
      if (filtered.length === 0) {
        const fresh: SavedChat = {
          id: "chat-" + Date.now(),
          title: "Nova conversa",
          messages: [],
          updatedAt: Date.now(),
        };
        setActiveChatId(fresh.id);
        return [fresh];
      }
      if (activeChatId === chatId) {
        setActiveChatId(filtered[0].id);
      }
      return filtered;
    });
  };

  // State to hold live metrics
  const [liveMetrics, setLiveMetrics] = useState<GenerationMetrics | null>(null);
  const generationStartTime = useRef<number>(0);

  // Interval for live metrics
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (llm.isGenerating) {
      interval = setInterval(() => {
        const elapsed = performance.now() - generationStartTime.current;
        const currentTokens = llm.getGeneratedTokenCount();
        setLiveMetrics({
          durationMs: elapsed,
          tokenCount: currentTokens,
          tokensPerSecond: currentTokens > 0 ? Number((currentTokens / (elapsed / 1000)).toFixed(1)) : 0,
        });
      }, 500);
    } else {
      setLiveMetrics(null);
    }
    return () => clearInterval(interval);
  }, [llm.isGenerating, llm.getGeneratedTokenCount]);


  async function handleSendMessage(customText?: string) {
    if (!llm || !llm.isReady) return;
    const textToSend = (customText || inputMessage).trim();
    if (!textToSend || llm.isGenerating) return;

    setInputMessage("");
    const currentMessages = activeChat?.messages || [];
    const isFirstMessage = currentMessages.length === 0;

    const userMsg: AppMessage = { role: "user", content: textToSend };
    const updatedMessages = [...currentMessages, userMsg];

    const newTitle = isFirstMessage
      ? textToSend.length > 28 ? textToSend.slice(0, 25) + "..." : textToSend
      : activeChat?.title || "Conversa";

    // Commit User Message
    setChats((prev) =>
      prev.map((c) =>
        c.id === activeChatId
          ? { ...c, title: newTitle, messages: updatedMessages, updatedAt: Date.now() }
          : c
      )
    );

    try {
      const historyForModel = updatedMessages.map(m => ({ role: m.role, content: m.content }));
      
      generationStartTime.current = performance.now();
      
      // Native Generate Call (This streams into llm.response)
      await llm.generate([
        { role: 'system', content: "Você é um assistente prestativo. Responda em português." },
        ...historyForModel
      ]);

      const elapsed = performance.now() - generationStartTime.current;
      const finalTokens = llm.getGeneratedTokenCount();
      
      const assistantMsg: AppMessage = {
        role: 'assistant',
        content: llm.response, // wait, llm.response might not be updated inline immediately in the hook state here, but we can capture it using an effect or waiting... 
        // ACTUALLY, generate returns void but updates state. If we read llm.response here it might be stale.
        // Let's use a trick: save a flag to append when generation completes.
      };
      
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error);
      Alert.alert("Ops!", "Não foi possível enviar a mensagem.");
    }
  }

  // Effect to capture the final message after generation completes
  const [wasGenerating, setWasGenerating] = useState(false);
  useEffect(() => {
    if (llm.isGenerating) {
      setWasGenerating(true);
    } else if (wasGenerating && !llm.isGenerating) {
      setWasGenerating(false);
      // Generation just finished!
      const elapsed = performance.now() - generationStartTime.current;
      const finalTokens = llm.getGeneratedTokenCount();
      const tokensPerSec = finalTokens > 0 ? Number((finalTokens / (elapsed / 1000)).toFixed(1)) : 0;
      
      if (llm.response.trim().length > 0) {
        setChats((prev) =>
          prev.map((c) => {
            if (c.id === activeChatId) {
              return { 
                ...c, 
                messages: [
                  ...c.messages, 
                  { 
                    role: 'assistant', 
                    content: llm.response,
                    metrics: { durationMs: elapsed, tokenCount: finalTokens, tokensPerSecond: tokensPerSec } 
                  }
                ], 
                updatedAt: Date.now() 
              };
            }
            return c;
          })
        );
      }
    }
  }, [llm.isGenerating]);


  const displayedMessages = activeChat?.messages || [];

  const renderMessage = useCallback((message: AppMessage, index: number) => {
    const isUser = message.role === "user";
    return (
      <View key={index} style={[styles.messageRow, isUser ? styles.userRow : styles.aiRow]}>
        <View style={[styles.bubble, isUser ? styles.userBubble : styles.aiBubble]}>
          {!isUser && <Text style={styles.roleLabel}>Assistente</Text>}
          
          {isUser ? (
            <Text style={styles.userMessageText}>{message.content}</Text>
          ) : (
            <Markdown 
              style={{ 
                body: { color: '#ececec', fontSize: 15, lineHeight: 22 },
                code_block: { backgroundColor: '#1a1a1a', padding: 8, borderRadius: 6, color: '#e4e4e7' },
                code_inline: { backgroundColor: '#1a1a1a', color: '#e4e4e7', borderRadius: 4 }
              }}
            >
              {message.content}
            </Markdown>
          )}

          {!isUser && message.metrics && (
            <View style={styles.metricsContainer}>
              <View style={styles.metricsBadge}>
                <Text style={styles.metricsIcon}>⏱</Text>
                <Text style={styles.metricsText}>
                  {(message.metrics.durationMs / 1000).toFixed(2)}s
                </Text>
              </View>
              <View style={styles.metricsDivider} />
              <View style={styles.metricsBadge}>
                <Text style={styles.metricsText}>
                  {message.metrics.tokenCount} tokens
                </Text>
              </View>
              <View style={styles.metricsDivider} />
              <View style={styles.metricsBadge}>
                <Text style={styles.metricsSpeedText}>
                  {message.metrics.tokensPerSecond} tok/s
                </Text>
              </View>
            </View>
          )}
        </View>
      </View>
    );
  }, []);

  const progressPercent = Math.min(100, Math.max(0, Math.round((llm.downloadProgress || 0) * 100)));
  const currentPhase = progressPercent < 30 ? 0 : progressPercent < 70 ? 1 : progressPercent < 95 ? 2 : 3;

  if (appPhase === "booting") {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "#000000" }}>
          <ActivityIndicator size="large" color="#ffffff" />
          <Text style={{ color: "#ffffff", marginTop: 24, fontSize: 16, fontWeight: "500", letterSpacing: 1 }}>
            EXECUTORCH ON-DEVICE
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  if (shouldLoadModel && !llm.isReady) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.loadingContainer}>
          <FallingStarsBackground />

          <View style={styles.loadingContent}>
            <View style={styles.loadingBadge}>
              <View style={styles.loadingBadgeDot} />
              <Text style={styles.loadingBadgeText}>EXECUTORCH • ON-DEVICE</Text>
            </View>

            <View style={styles.counterWrapper}>
              <Text style={styles.counterNumber}>{progressPercent}</Text>
              <Text style={styles.counterPercent}>%</Text>
            </View>

            <Text style={styles.loadingTitle}>Carregando Modelo</Text>
            <Text style={styles.loadingSubtext}>
              {loadingMessages[currentPhase]}
            </Text>

            <View style={styles.progressBarContainer}>
              <View style={styles.progressBarTrack}>
                <View
                  style={[{
                    height: "100%",
                    width: `${Math.max(4, progressPercent)}%`,
                    backgroundColor: "#ffffff",
                    borderRadius: 3,
                  }]}
                />
              </View>
              <View style={styles.progressMetaRow}>
                <Text style={styles.progressMetaLabel}>
                  {progressPercent < 100 ? "CARREGANDO PARA RAM" : "SISTEMA PRONTO"}
                </Text>
                <Text style={styles.progressMetaValue}>
                  {progressPercent < 100 ? `${(progressPercent).toFixed(0)}%` : "100%"}
                </Text>
              </View>
            </View>

            <View style={styles.loadingCard}>
              <View style={styles.loadingStepItem}>
                <View style={styles.loadingStepLeft}>
                  <View style={progressPercent >= 15 ? styles.loadingStepDotDone : styles.loadingStepDot} />
                  <Text style={progressPercent >= 15 ? styles.loadingStepDoneText : styles.loadingStepActiveText}>
                    Alocação de tensores na memória
                  </Text>
                </View>
                <Text style={progressPercent >= 15 ? styles.loadingStepTagActive : styles.loadingStepTag}>
                  {progressPercent >= 15 ? "OK" : "PROCESSANDO"}
                </Text>
              </View>

              <View style={styles.loadingStepItem}>
                <View style={styles.loadingStepLeft}>
                  <View style={progressPercent >= 65 ? styles.loadingStepDotDone : progressPercent >= 15 ? styles.loadingStepDot : styles.loadingStepDotPending} />
                  <Text style={progressPercent >= 65 ? styles.loadingStepDoneText : progressPercent >= 15 ? styles.loadingStepActiveText : styles.loadingStepText}>
                    Download dos pesos SpinQuant
                  </Text>
                </View>
                <Text style={progressPercent >= 65 ? styles.loadingStepTagActive : styles.loadingStepTag}>
                  {progressPercent >= 65 ? "OK" : progressPercent >= 15 ? "BAIXANDO" : "AGUARDANDO"}
                </Text>
              </View>

              <View style={styles.loadingStepItem}>
                <View style={styles.loadingStepLeft}>
                  <View style={progressPercent >= 95 ? styles.loadingStepDotDone : progressPercent >= 65 ? styles.loadingStepDot : styles.loadingStepDotPending} />
                  <Text style={progressPercent >= 95 ? styles.loadingStepDoneText : progressPercent >= 65 ? styles.loadingStepActiveText : styles.loadingStepText}>
                    Compilação de grafo para NPU/GPU
                  </Text>
                </View>
                <Text style={progressPercent >= 95 ? styles.loadingStepTagActive : styles.loadingStepTag}>
                  {progressPercent >= 95 ? "OK" : progressPercent >= 65 ? "OTIMIZANDO" : "AGUARDANDO"}
                </Text>
              </View>
            </View>

            <View style={styles.loadingFooterTag}>
              <Text style={styles.loadingFooterText}>
                Inferência 100% Offline • Sem Conexão Externa
              </Text>
            </View>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.container}
      >
        <FallingStarsBackground />

        <View style={styles.floatingHeader}>
          <TouchableOpacity onPress={() => setIsDrawerOpen(true)} style={styles.floatingButton}>
            <Text style={{ fontSize: 16, color: "#ffffff" }}>☰</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleNewChat} style={styles.floatingButton}>
            <Text style={{ fontSize: 18, color: "#ffffff", fontWeight: "bold", lineHeight: 18 }}>＋</Text>
          </TouchableOpacity>
        </View>

        <ScrollView
          style={styles.messagesContainer}
          contentContainerStyle={styles.messagesContent}
        >
          {displayedMessages.map((message, index) => renderMessage(message, index))}

          {llm.isGenerating && (
            <View style={[styles.messageRow, styles.aiRow]}>
              <View style={[styles.bubble, styles.aiBubble]}>
                <Text style={styles.roleLabel}>Assistente</Text>
                <Markdown 
                  style={{ 
                    body: { color: '#ececec', fontSize: 15, lineHeight: 22 },
                  }}
                >
                  {llm.response || "..."}
                </Markdown>

                {liveMetrics && (
                  <View style={styles.metricsContainer}>
                    <View style={styles.metricsBadge}>
                      <Text style={styles.metricsIcon}>⏱</Text>
                      <Text style={styles.metricsText}>
                        {(liveMetrics.durationMs / 1000).toFixed(1)}s
                      </Text>
                    </View>
                    <View style={styles.metricsDivider} />
                    <View style={styles.metricsBadge}>
                      <Text style={styles.metricsText}>
                        {liveMetrics.tokenCount} tokens
                      </Text>
                    </View>
                    {liveMetrics.tokensPerSecond > 0 && (
                      <>
                        <View style={styles.metricsDivider} />
                        <View style={styles.metricsBadge}>
                          <Text style={styles.metricsSpeedText}>
                            {liveMetrics.tokensPerSecond} tok/s
                          </Text>
                        </View>
                      </>
                    )}
                  </View>
                )}
              </View>
            </View>
          )}
        </ScrollView>

        <View style={styles.inputArea}>
          <View style={styles.inputWrapper}>
            <TextInput
              value={inputMessage}
              onChangeText={setInputMessage}
              placeholder="Digite sua mensagem..."
              placeholderTextColor="#525252"
              style={styles.textInput}
              multiline
              maxLength={500}
              editable={!llm.isGenerating}
              onSubmitEditing={() => handleSendMessage()}
            />
            <TouchableOpacity
              onPress={() => handleSendMessage()}
              disabled={!inputMessage.trim() || llm.isGenerating}
              style={[styles.sendButton, (!inputMessage.trim() || llm.isGenerating) && styles.sendButtonDisabled]}
            >
              <Text style={styles.sendButtonText}>{llm.isGenerating ? "..." : "➤"}</Text>
            </TouchableOpacity>
          </View>
        </View>

        <Modal visible={isDrawerOpen} transparent>
          <TouchableOpacity style={styles.drawerOverlay} onPress={() => setIsDrawerOpen(false)} activeOpacity={1}>
            <View style={styles.drawer}>
              <View style={styles.drawerHeader}>
                <Text style={styles.drawerTitle}>Conversas</Text>
                <TouchableOpacity onPress={() => setIsDrawerOpen(false)} style={styles.closeButton}>
                  <Text style={{ fontSize: 18, color: "#737373", fontWeight: "bold" }}>✕</Text>
                </TouchableOpacity>
              </View>

              <TouchableOpacity onPress={handleNewChat} style={styles.newChatButton}>
                <Text style={{ fontSize: 16, color: "#000000", fontWeight: "bold", marginRight: 6 }}>＋</Text>
                <Text style={styles.newChatButtonText}>Novo Chat</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  setIsDrawerOpen(false);
                  setIsModelsModalOpen(true);
                }}
                style={styles.drawerModelsButton}
              >
                <Text style={{ fontSize: 15, color: "#e4e4e7" }}>⚡</Text>
                <Text style={styles.drawerModelsButtonText}>Modelos</Text>
              </TouchableOpacity>

              <ScrollView style={styles.chatList}>
                <Text style={styles.sectionLabel}>Histórico Local</Text>
                {chats.map((chat) => {
                  const isActive = chat.id === activeChatId;
                  return (
                    <TouchableOpacity
                      key={chat.id}
                      onPress={() => handleSelectChat(chat)}
                      style={[styles.chatItem, isActive && styles.chatItemActive]}
                    >
                      <View style={styles.chatItemContent}>
                        <Text style={[styles.chatItemTitle, isActive && { color: "#ffffff" }]} numberOfLines={1}>
                          {chat.title}
                        </Text>
                        <Text style={styles.chatItemDate}>
                          {chat.messages.length} {chat.messages.length === 1 ? "mensagem" : "mensagens"}
                        </Text>
                      </View>
                      <TouchableOpacity onPress={() => handleDeleteChat(chat.id)} style={styles.deleteButton}>
                        <Text style={{ fontSize: 13, color: "#737373" }}>✕</Text>
                      </TouchableOpacity>
                    </TouchableOpacity>
                  );
                })}
              
              </ScrollView>

              {/* Botão Flutuante de Importar Modelos (Canto Inferior Direito) */}
              <TouchableOpacity
                onPress={async () => {
                  try {
                    const res = await DocumentPicker.getDocumentAsync({
                      type: ['*/*'],
                      copyToCacheDirectory: false,
                    });
                    
                    if (res.canceled === false && res.assets && res.assets.length > 0) {
                      const file = res.assets[0];
                      if (!file.name.endsWith('.pte')) {
                        Alert.alert("Erro", "O aplicativo suporta apenas modelos compilados no formato ExecuTorch (.pte).");
                        return;
                      }
                      
                      const destPath = (FileSystem as any).documentDirectory + file.name;
                      await FileSystem.copyAsync({
                        from: file.uri,
                        to: destPath
                      });
                      
                      const sizeMb = (file.size ? file.size / (1024 * 1024) : 0).toFixed(0);
                      const newModel = {
                        id: "custom-" + Date.now(),
                        name: file.name.replace(/\.[^/.]+$/, ""),
                        parameters: "Custom",
                        format: "ExecuTorch (.pte)",
                        size: Number(sizeMb) > 1024 ? `${(Number(sizeMb) / 1024).toFixed(1)} GB` : `${sizeMb} MB`,
                        contextLength: "Custom ctx",
                        description: "Modelo importado do armazenamento interno.",
                        status: "downloaded" as ModelStatus,
                        libModel: {
                           modelSource: destPath,
                           tokenizerSource: LLAMA3_2_1B_SPINQUANT.tokenizerSource,
                           tokenizerConfigSource: LLAMA3_2_1B_SPINQUANT.tokenizerConfigSource
                        }
                      };
                      
                      setModels((prev) => [newModel, ...prev]);
                      Alert.alert("Sucesso", `O modelo ${file.name} foi importado com sucesso!`);
                    }
                  } catch (e) {
                    console.error(e);
                    Alert.alert("Erro", "Falha ao importar o arquivo.");
                  }
                }}
                style={styles.importFab}
                activeOpacity={0.85}
              >
                <Text style={styles.importFabIcon}>📂</Text>
                <Text style={styles.importFabText}>Importar modelos</Text>
              </TouchableOpacity>

            </View>
          </TouchableOpacity>
        </Modal>

        {/* Modal Gerenciador de Modelos */}
        <Modal visible={isModelsModalOpen} transparent={false}>
          <SafeAreaView style={styles.safeArea}>
            <View style={styles.modelsContainer}>
              <FallingStarsBackground />

              <View style={styles.modelsHeader}>
                <View>
                  <Text style={styles.modelsHeaderTitle}>Modelos</Text>
                  <Text style={styles.modelsHeaderSubtitle}>
                    Download e memória on-device (ExecuTorch)
                  </Text>
                </View>
                <TouchableOpacity
                  onPress={() => setIsModelsModalOpen(false)}
                  style={styles.modelsCloseBtn}
                >
                  <Text style={styles.modelsCloseBtnText}>✕</Text>
                </TouchableOpacity>
              </View>

              <View style={styles.modelsStatsBar}>
                <View style={styles.modelsStatItem}>
                  <Text style={styles.modelsStatLabel}>Armazenamento:</Text>
                  <Text style={styles.modelsStatValue}>
                    {models.filter((m) => m.status !== "available").length} no aparelho
                  </Text>
                </View>
                <View style={styles.modelsStatItem}>
                  <Text style={styles.modelsStatLabel}>RAM:</Text>
                  <Text
                    style={[
                      styles.modelsStatValue,
                      {
                        color: models.some((m) => m.status === "loaded") ? "#34d399" : "#a1a1aa",
                      },
                    ]}
                  >
                    {models.find((m) => m.status === "loaded")
                      ? `${models.find((m) => m.status === "loaded")?.name.split(" ")[0]} (Ativo)`
                      : "Sem modelo na RAM"}
                  </Text>
                </View>
              </View>

              <ScrollView
                style={styles.modelsList}
                contentContainerStyle={styles.modelsListContent}
              >
                <Text style={styles.modelsSectionHeader}>Catálogo de Modelos</Text>

                {models.map((model) => {
                  const isLoaded = model.status === "loaded";
                  
                  return (
                    <View key={model.id} style={[styles.modelCard, isLoaded && styles.modelCardActive]}>
                      <View style={styles.modelCardTop}>
                        <View style={styles.modelCardTitleRow}>
                          <Text style={styles.modelCardName}>{model.name}</Text>
                          <Text style={styles.modelCardTag}>{model.format}</Text>
                        </View>
                        <View
                          style={[
                            styles.modelStatusBadge,
                            model.status === "available" && styles.badgeAvailable,
                            model.status === "downloaded" && styles.badgeDownloaded,
                            isLoaded && styles.badgeLoaded,
                          ]}
                        >
                          <Text
                            style={[
                              styles.modelStatusText,
                              {
                                color:
                                  model.status === "available"
                                    ? "#a1a1aa"
                                    : isLoaded
                                    ? "#34d399"
                                    : "#60a5fa",
                              },
                            ]}
                          >
                            {model.status === "available" ? "Nuvem" : model.status === "downloaded" ? "No Aparelho" : "Ativo na RAM"}
                          </Text>
                        </View>
                      </View>

                      <Text style={styles.modelCardDesc}>{model.description}</Text>

                      <View style={styles.modelCardMetaRow}>
                        <Text style={styles.modelMetaText}>
                          Tamanho: <Text style={styles.modelMetaValue}>{model.size}</Text>
                        </Text>
                        <Text style={styles.modelMetaText}>
                          Params: <Text style={styles.modelMetaValue}>{model.parameters}</Text>
                        </Text>
                        <Text style={styles.modelMetaText}>
                          Janela: <Text style={styles.modelMetaValue}>{model.contextLength}</Text>
                        </Text>
                      </View>

                      <View style={styles.modelCardActions}>
                        {model.status === "available" && (
                          <TouchableOpacity
                            style={styles.btnDownload}
                            onPress={() => handleDownloadModel(model.id)}
                          >
                            <Text style={styles.btnDownloadText}>↓ Baixar do Hub</Text>
                          </TouchableOpacity>
                        )}

                        {(model.status === "downloaded" || isLoaded) && (
                          <>
                            {!isLoaded ? (
                              <TouchableOpacity
                                style={styles.btnLoad}
                                onPress={() => handleLoadModel(model.id)}
                              >
                                <Text style={styles.btnLoadText}>⚡ Carregar na RAM</Text>
                              </TouchableOpacity>
                            ) : (
                              <TouchableOpacity
                                style={styles.btnUnload}
                                onPress={() => handleUnloadModel(model.id)}
                              >
                                <Text style={styles.btnUnloadText}>⏏ Descarregar</Text>
                              </TouchableOpacity>
                            )}
                          </>
                        )}
                      </View>
                    </View>
                  );
                })}
              </ScrollView>
            </View>
          </SafeAreaView>
        </Modal>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  );
}

registerRootComponent(App);
