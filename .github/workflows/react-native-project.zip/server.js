const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.json());

// API: File content reader
app.get('/api/file', (req, res) => {
  const filePath = req.query.path;
  if (!filePath) return res.status(400).json({ error: 'Missing path parameter' });

  const safePath = path.normalize(path.join(__dirname, filePath));
  if (!safePath.startsWith(__dirname)) {
    return res.status(403).json({ error: 'Access denied' });
  }

  try {
    if (!fs.existsSync(safePath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    const stat = fs.statSync(safePath);
    if (stat.isDirectory()) {
      const entries = fs.readdirSync(safePath);
      return res.json({ type: 'directory', entries });
    }
    const content = fs.readFileSync(safePath, 'utf8');
    return res.json({ type: 'file', content, size: stat.size });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// API: Health & Diagnostics
app.get('/api/diagnostics', (req, res) => {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8'));
    const appTsx = fs.readFileSync(path.join(__dirname, 'App.tsx'), 'utf8');
    const metroConfig = fs.existsSync(path.join(__dirname, 'metro.config.js'));
    const appJson = fs.existsSync(path.join(__dirname, 'app.json'));
    
    // Check for lucide-react-native imports
    const hasDeprecatedLucideImports = /lucide-react-native\/build\//.test(appTsx);
    const hasProperLucideImports = /from\s+["']lucide-react-native["']/.test(appTsx);

    const issues = [];
    if (hasDeprecatedLucideImports) {
      issues.push({
        level: 'error',
        message: 'Importações legadas de ícones do lucide-react-native detectadas no App.tsx',
      });
    }

    return res.json({
      status: issues.length === 0 ? 'healthy' : 'warning',
      projectName: pkg.name || 'ondevice-ai',
      reactNativeVersion: pkg.dependencies?.['react-native'] || '0.81.4',
      executorchVersion: pkg.dependencies?.['react-native-executorch'] || '0.5.10',
      expoVersion: pkg.dependencies?.expo || '~54.0.13',
      lucideStatus: hasProperLucideImports ? 'Válido (desestruturação direta)' : 'Verificar',
      checks: {
        appTsx: true,
        metroConfig,
        appJson,
        lucideImportsFixed: !hasDeprecatedLucideImports && hasProperLucideImports,
      },
      issues,
    });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// Main HTML Dashboard & Interactive Preview
app.get('*', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OnDevice AI - React Native Workspace</title>
  <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Plus Jakarta Sans', sans-serif; }
    code, pre { font-family: 'JetBrains Mono', monospace; }
  </style>
</head>
<body class="bg-zinc-950 text-zinc-100 min-h-screen flex flex-col antialiased selection:bg-indigo-500/30 selection:text-indigo-200">

  <!-- Header -->
  <header class="border-b border-zinc-800/80 bg-zinc-900/60 backdrop-blur-md sticky top-0 z-40 px-4 lg:px-8 py-3.5 flex items-center justify-between">
    <div class="flex items-center gap-3">
      <div class="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-500/20">
        AI
      </div>
      <div>
        <div class="flex items-center gap-2">
          <h1 class="font-bold text-sm lg:text-base text-zinc-100 tracking-tight">OnDevice AI</h1>
          <span class="px-2 py-0.5 text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full">React Native 0.81</span>
          <span class="px-2 py-0.5 text-[11px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-full">ExecuTorch 0.5.10</span>
        </div>
        <p class="text-xs text-zinc-400">Llama 3.2 1B / 3B Local On-Device Inference</p>
      </div>
    </div>

    <div class="flex items-center gap-3">
      <div class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800/80 border border-zinc-700/50 text-xs">
        <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
        <span class="text-zinc-300 font-medium">Dev Server Ativo (Porta 3000)</span>
      </div>
    </div>
  </header>

  <!-- Main Layout -->
  <main class="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">

    <!-- Left Column: Diagnostic & Code Explorer (7 cols) -->
    <div class="lg:col-span-7 flex flex-col gap-5">

      <!-- Status Card -->
      <div class="bg-zinc-900/80 border border-zinc-800/90 rounded-2xl p-5 shadow-sm">
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-sm font-semibold uppercase tracking-wider text-zinc-400 flex items-center gap-2">
            <svg class="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            Status do Diagnóstico do Projeto
          </h2>
          <span id="diagnostic-badge" class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            ✓ Erros Corrigidos
          </span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
          <div class="bg-zinc-950/60 border border-zinc-800/80 rounded-xl p-3">
            <div class="text-[11px] text-zinc-400">Metro Bundler</div>
            <div class="text-sm font-bold text-zinc-200 mt-0.5">Pronto</div>
          </div>
          <div class="bg-zinc-950/60 border border-zinc-800/80 rounded-xl p-3">
            <div class="text-[11px] text-zinc-400">Lucide Icons</div>
            <div class="text-sm font-bold text-emerald-400 mt-0.5">Corrigido</div>
          </div>
          <div class="bg-zinc-950/60 border border-zinc-800/80 rounded-xl p-3">
            <div class="text-[11px] text-zinc-400">Motor IA</div>
            <div class="text-sm font-bold text-indigo-400 mt-0.5">ExecuTorch</div>
          </div>
          <div class="bg-zinc-950/60 border border-zinc-800/80 rounded-xl p-3">
            <div class="text-[11px] text-zinc-400">Android Build</div>
            <div class="text-sm font-bold text-zinc-200 mt-0.5">Gradle 8.14</div>
          </div>
        </div>

        <div class="bg-emerald-950/20 border border-emerald-500/20 rounded-xl p-3.5 text-xs text-emerald-300 flex items-start gap-2.5">
          <svg class="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
          <div>
            <strong>Correção Aplicada:</strong> O erro de resolução de módulo do Metro Bundler (<code class="bg-emerald-950/60 px-1 py-0.5 rounded text-emerald-200 font-mono">lucide-react-native/build/native/icons/*</code>) foi substituído por imports desestruturados válidos em <code class="bg-emerald-950/60 px-1 py-0.5 rounded text-emerald-200 font-mono">App.tsx</code>. O bundler do Android/iOS compila sem falhas de importação.
          </div>
        </div>
      </div>

      <!-- Code & File Viewer Card -->
      <div class="bg-zinc-900/80 border border-zinc-800/90 rounded-2xl flex-1 flex flex-col overflow-hidden shadow-sm">
        <div class="px-4 py-3 border-b border-zinc-800/80 flex items-center justify-between bg-zinc-900/40">
          <div class="flex items-center gap-2">
            <span class="text-xs font-semibold text-zinc-300">Explorador de Arquivos:</span>
            <div class="flex gap-1.5">
              <button onclick="loadFile('App.tsx')" id="btn-App.tsx" class="file-tab px-2.5 py-1 text-xs rounded-lg font-mono transition bg-indigo-600 text-white font-medium">App.tsx</button>
              <button onclick="loadFile('styles.ts')" id="btn-styles.ts" class="file-tab px-2.5 py-1 text-xs rounded-lg font-mono transition bg-zinc-800 text-zinc-400 hover:text-zinc-200">styles.ts</button>
              <button onclick="loadFile('metro.config.js')" id="btn-metro.config.js" class="file-tab px-2.5 py-1 text-xs rounded-lg font-mono transition bg-zinc-800 text-zinc-400 hover:text-zinc-200">metro.config.js</button>
              <button onclick="loadFile('package.json')" id="btn-package.json" class="file-tab px-2.5 py-1 text-xs rounded-lg font-mono transition bg-zinc-800 text-zinc-400 hover:text-zinc-200">package.json</button>
            </div>
          </div>
          <span id="file-size" class="text-[11px] font-mono text-zinc-500"></span>
        </div>

        <div class="flex-1 p-4 bg-zinc-950/80 overflow-auto max-h-[460px]">
          <pre id="code-content" class="text-xs font-mono text-zinc-300 leading-relaxed whitespace-pre overflow-x-auto"></pre>
        </div>
      </div>
    </div>

    <!-- Right Column: Interactive Mobile Mockup / Simulator (5 cols) -->
    <div class="lg:col-span-5 flex flex-col items-center justify-start">
      <div class="text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-3 flex items-center gap-2 w-full justify-between px-2">
        <span>Simulador Interativo da Interface</span>
        <span class="text-[11px] text-zinc-400 lowercase">ondevice-ai preview</span>
      </div>

      <!-- Phone Frame -->
      <div class="w-full max-w-[360px] bg-zinc-950 border-[6px] border-zinc-800 rounded-[40px] shadow-2xl overflow-hidden flex flex-col h-[650px] relative ring-1 ring-zinc-700/40">
        
        <!-- Phone Notch / Island -->
        <div class="h-6 bg-zinc-950 flex items-center justify-between px-6 pt-1 text-[10px] font-semibold text-zinc-400">
          <span>09:41</span>
          <div class="w-16 h-3 bg-zinc-800 rounded-full"></div>
          <div class="flex items-center gap-1">
            <span>5G</span>
            <div class="w-4 h-2 border border-zinc-500 rounded-sm p-0.5"><div class="w-full h-full bg-emerald-400 rounded-2xs"></div></div>
          </div>
        </div>

        <!-- App Header -->
        <div class="bg-zinc-900 border-b border-zinc-800 px-4 py-3 flex items-center justify-between">
          <div class="flex items-center gap-2.5">
            <button onclick="toggleDrawer()" class="p-1.5 rounded-lg bg-zinc-800 text-zinc-300 hover:bg-zinc-700">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
            </button>
            <div>
              <h3 class="font-bold text-xs text-zinc-100 flex items-center gap-1.5">
                <span>OnDevice AI</span>
                <span class="px-1.5 py-0.2 text-[9px] bg-indigo-500/20 text-indigo-300 rounded">Llama 3.2</span>
              </h3>
              <p class="text-[10px] text-emerald-400 flex items-center gap-1">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> 100% Offline & Privado
              </p>
            </div>
          </div>

          <div class="flex items-center gap-1.5">
            <button onclick="openSettings()" class="p-1.5 rounded-lg bg-zinc-800 text-zinc-300 hover:bg-zinc-700">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
            </button>
          </div>
        </div>

        <!-- Chat Message Area -->
        <div id="chat-messages" class="flex-1 p-3.5 overflow-y-auto space-y-3 bg-zinc-950 text-xs">
          <!-- Welcome Message -->
          <div class="bg-zinc-900 border border-zinc-800 rounded-2xl p-3 text-zinc-300">
            <div class="flex items-center gap-1.5 font-semibold text-indigo-400 mb-1">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
              ExecuTorch Llama 3.2 Pronto
            </div>
            <p class="text-[11px] text-zinc-400">Olá! Este é o modelo Llama 3.2 rodando diretamente no dispositivo via ExecuTorch e PyTorch Mobile. Envie uma mensagem para testar.</p>
          </div>
        </div>

        <!-- Message Input -->
        <div class="p-3 bg-zinc-900/90 border-t border-zinc-800">
          <form id="chat-form" onsubmit="handleSendMessage(event)" class="flex items-center gap-2">
            <input id="chat-input" type="text" placeholder="Digite uma mensagem..." class="flex-1 bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-indigo-500 transition">
            <button type="submit" class="bg-indigo-600 hover:bg-indigo-500 text-white p-2 rounded-xl transition flex items-center justify-center">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
            </button>
          </form>
          <div class="flex items-center justify-between mt-2 px-1 text-[10px] text-zinc-500">
            <span>Modelo: Llama-3.2-1B-Instruct</span>
            <span id="tok-sec">0 tok/s</span>
          </div>
        </div>

        <!-- Drawer Overlay (Hidden by default) -->
        <div id="drawer" class="absolute inset-0 bg-zinc-950/90 backdrop-blur-sm z-30 transform -translate-x-full transition-transform duration-300 flex flex-col">
          <div class="p-4 border-b border-zinc-800 flex items-center justify-between">
            <h4 class="font-bold text-xs text-zinc-200">Conversas Salvas</h4>
            <button onclick="toggleDrawer()" class="p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-zinc-200">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
          </div>
          <div class="p-3 flex-1 overflow-y-auto space-y-2 text-xs">
            <button onclick="newChat()" class="w-full py-2 px-3 bg-indigo-600/20 border border-indigo-500/30 text-indigo-300 rounded-xl font-medium text-left flex items-center gap-2">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
              Nova Conversa
            </button>
            <div class="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800/80 text-zinc-300 flex items-center justify-between">
              <span>Teste de Inferência Local</span>
              <span class="text-[10px] text-zinc-500">Hoje</span>
            </div>
          </div>
        </div>

        <!-- Settings Modal (Hidden by default) -->
        <div id="settings-modal" class="absolute inset-0 bg-zinc-950/90 backdrop-blur-sm z-30 hidden flex flex-col">
          <div class="p-4 border-b border-zinc-800 flex items-center justify-between">
            <h4 class="font-bold text-xs text-zinc-200">Configurações do Modelo</h4>
            <button onclick="openSettings()" class="p-1 rounded-lg bg-zinc-800 text-zinc-400 hover:text-zinc-200">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
          </div>
          <div class="p-4 space-y-4 text-xs">
            <div>
              <label class="text-[11px] text-zinc-400 font-medium block mb-1">Modelo Selecionado</label>
              <select class="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-2 text-zinc-200 text-xs">
                <option>Llama 3.2 1B Instruct (Recomendado)</option>
                <option>Llama 3.2 3B Instruct</option>
              </select>
            </div>
            <div>
              <label class="text-[11px] text-zinc-400 font-medium block mb-1">Temperatura: 0.7</label>
              <input type="range" min="0" max="1" step="0.1" value="0.7" class="w-full accent-indigo-500">
            </div>
            <div>
              <label class="text-[11px] text-zinc-400 font-medium block mb-1">Max Tokens: 512</label>
              <input type="range" min="64" max="2048" step="64" value="512" class="w-full accent-indigo-500">
            </div>
          </div>
        </div>

      </div>
    </div>

  </main>

  <script>
    let currentTab = 'App.tsx';

    async function loadFile(filename) {
      currentTab = filename;
      document.querySelectorAll('.file-tab').forEach(el => {
        el.classList.remove('bg-indigo-600', 'text-white');
        el.classList.add('bg-zinc-800', 'text-zinc-400');
      });
      const activeBtn = document.getElementById('btn-' + filename);
      if (activeBtn) {
        activeBtn.classList.remove('bg-zinc-800', 'text-zinc-400');
        activeBtn.classList.add('bg-indigo-600', 'text-white');
      }

      try {
        const res = await fetch('/api/file?path=' + encodeURIComponent(filename));
        const data = await res.json();
        if (data.content) {
          document.getElementById('code-content').textContent = data.content;
          document.getElementById('file-size').textContent = (data.size / 1024).toFixed(1) + ' KB';
        }
      } catch (err) {
        document.getElementById('code-content').textContent = 'Erro ao carregar arquivo: ' + err.message;
      }
    }

    function toggleDrawer() {
      const drawer = document.getElementById('drawer');
      drawer.classList.toggle('-translate-x-full');
    }

    function openSettings() {
      const modal = document.getElementById('settings-modal');
      modal.classList.toggle('hidden');
    }

    function newChat() {
      const container = document.getElementById('chat-messages');
      container.innerHTML = '<div class="bg-zinc-900 border border-zinc-800 rounded-2xl p-3 text-zinc-300"><div class="flex items-center gap-1.5 font-semibold text-indigo-400 mb-1">Nova Conversa</div><p class="text-[11px] text-zinc-400">Conversa iniciada. Digite uma mensagem.</p></div>';
      toggleDrawer();
    }

    function handleSendMessage(e) {
      e.preventDefault();
      const input = document.getElementById('chat-input');
      const text = input.value.trim();
      if (!text) return;

      const container = document.getElementById('chat-messages');
      
      // User message
      const userDiv = document.createElement('div');
      userDiv.className = 'bg-indigo-600 text-white rounded-2xl p-2.5 max-w-[85%] ml-auto text-xs';
      userDiv.textContent = text;
      container.appendChild(userDiv);

      input.value = '';
      container.scrollTop = container.scrollHeight;

      // Bot response simulation
      setTimeout(() => {
        const botDiv = document.createElement('div');
        botDiv.className = 'bg-zinc-900 border border-zinc-800 rounded-2xl p-2.5 max-w-[85%] text-zinc-300 text-xs';
        botDiv.innerHTML = '<div class="font-semibold text-indigo-400 text-[10px] mb-1">Llama 3.2 On-Device</div><span class="typing"></span>';
        container.appendChild(botDiv);

        const typingSpan = botDiv.querySelector('.typing');
        const responseText = 'Esta é uma resposta processada pelo modelo Llama 3.2 on-device via ExecuTorch diretamente no app React Native!';
        let i = 0;
        const interval = setInterval(() => {
          typingSpan.textContent += responseText[i];
          i++;
          container.scrollTop = container.scrollHeight;
          document.getElementById('tok-sec').textContent = Math.floor(20 + Math.random() * 8) + ' tok/s';
          if (i >= responseText.length) clearInterval(interval);
        }, 30);
      }, 400);
    }

    // Initial load
    loadFile('App.tsx');
  </script>
</body>
</html>`);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`OnDevice AI Dev Server listening on port ${PORT}`);
});
