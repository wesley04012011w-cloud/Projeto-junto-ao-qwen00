import React, { useState, useEffect, useCallback } from "react"
import {
  View,
  Text,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Alert,
  Platform,
  KeyboardAvoidingView,
  TouchableOpacity,
  SafeAreaView,
  Modal,
} from "react-native"
import { registerRootComponent } from "expo"
import {
  useLLM,
  Message,
  LLAMA3_2_1B_SPINQUANT,
} from "react-native-executorch"
import { styles } from "./styles"

export interface SavedChat {
  id: string
  title: string
  messages: Message[]
  updatedAt: number
}

const STORAGE_KEY = "@ondevice_ai_saved_chats"
const MODEL_LOADED_KEY = "@ondevice_ai_model_loaded"

const DEFAULT_INITIAL_CHATS: SavedChat[] = [
  {
    id: "chat-1",
    title: "Boas-vindas ao Llama 3.2",
    messages: [
      { role: "user", content: "Como funciona a IA on-device?" },
      {
        role: "assistant",
        content:
          "Olá! A IA on-device roda localmente na GPU/NPU do seu próprio dispositivo usando o PyTorch ExecuTorch. Nenhuma mensagem sua é enviada para servidores externos, garantindo privacidade total!",
      },
    ],
    updatedAt: Date.now() - 3600000,
  },
]

// Simulação de fases do modelo baseada no progresso real
const loadingMessages = [
  "Baixando pesos do modelo (~800MB)...",
  "Verificando integridade dos arquivos...",
  "Otimizando para NPU/GPU local...",
  "Quase lá! Preparando ambiente de inferência...",
]

class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; error: any }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props)
    this.state = { hasError: false, error: null }
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error }
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("ErrorBoundary capturou:", error, errorInfo)
  }

  render() {
    if (this.state.hasError) {
      return (
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.readyContainer}>
            <Text style={{ fontSize: 44, marginBottom: 16 }}>⚠️</Text>
            <Text style={styles.readyTitle}>Ocorreu um erro</Text>
            <Text style={[styles.readySubtext, { color: "#ef4444" }]}>
              {String(this.state.error?.message || this.state.error)}
            </Text>
            <TouchableOpacity
              onPress={() => this.setState({ hasError: false, error: null })}
              style={[styles.startButton, { marginTop: 20 }]}
            >
              <Text style={styles.startButtonText}>Reiniciar App</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      )
    }
    return this.props.children
  }
}

function MainApp() {
  const [inputMessage, setInputMessage] = useState("")
  const [isDrawerOpen, setIsDrawerOpen] = useState(false)
  const [chats, setChats] = useState<SavedChat[]>(DEFAULT_INITIAL_CHATS)
  const [activeChatId, setActiveChatId] = useState<string>(DEFAULT_INITIAL_CHATS[0].id)
  
  // Controle de carregamento do modelo
  const [shouldLoadModel, setShouldLoadModel] = useState(false)

  // useLLM SEMPRE chamado no topo do componente (respeita regras de hooks do React)
  // O parâmetro preventLoad: true impede o download até o usuário clicar no botão
  const llm = useLLM({
    model: LLAMA3_2_1B_SPINQUANT,
    preventLoad: !shouldLoadModel,
  })

  // Carregar chats salvos e verificar se modelo já foi ativado
  useEffect(() => {
    const loadChats = async () => {
      try {
        const AsyncStorage = await import("@react-native-async-storage/async-storage").catch(() => null)
        if (AsyncStorage?.default) {
          const saved = await AsyncStorage.default.getItem(STORAGE_KEY)
          if (saved) {
            const parsed = JSON.parse(saved)
            if (Array.isArray(parsed) && parsed.length > 0) {
              setChats(parsed)
              setActiveChatId(parsed[0].id)
            }
          }
          
          // Verifica se modelo já foi carregado antes
          const modelLoaded = await AsyncStorage.default.getItem(MODEL_LOADED_KEY)
          if (modelLoaded === "true") {
            setShouldLoadModel(true)
          }
        }
      } catch (e) {
        console.warn("Erro ao carregar dados:", e)
      }
    }
    loadChats()
  }, [])

  // Salvar chats automaticamente
  useEffect(() => {
    const saveChats = async () => {
      try {
        const AsyncStorage = await import("@react-native-async-storage/async-storage").catch(() => null)
        if (AsyncStorage?.default) {
          await AsyncStorage.default.setItem(STORAGE_KEY, JSON.stringify(chats))
        }
      } catch (e) {
        console.warn("Erro ao salvar chats:", e)
      }
    }
    saveChats()
  }, [chats])

  // Configurar LLM quando pronto
  useEffect(() => {
    if (!llm?.isReady) return
    llm.configure({
      chatConfig: {
        systemPrompt: "Você é um assistente útil e prestativo. Responda sempre em português de forma clara e concisa.",
        contextWindowLength: 4096,
      },
    })
    
    // Marca modelo como carregado permanentemente
    const markAsLoaded = async () => {
      try {
        const AsyncStorage = await import("@react-native-async-storage/async-storage").catch(() => null)
        if (AsyncStorage?.default) {
          await AsyncStorage.default.setItem(MODEL_LOADED_KEY, "true")
        }
      } catch (e) {
        console.warn("Erro ao marcar modelo:", e)
      }
    }
    markAsLoaded()
  }, [llm?.isReady])

  const activeChat = chats.find((c) => c.id === activeChatId)

  const handleStartDownload = () => {
    setShouldLoadModel(true)
  }

  const handleCancelDownload = () => {
    setShouldLoadModel(false)
    Alert.alert("Download pausado", "Você pode continuar o download quando desejar.")
  }

  const handleNewChat = () => {
    const newChat: SavedChat = {
      id: "chat-" + Date.now(),
      title: "Nova conversa",
      messages: [],
      updatedAt: Date.now(),
    }
    setChats((prev) => [newChat, ...prev])
    setActiveChatId(newChat.id)
    setIsDrawerOpen(false)
  }

  const handleSelectChat = (chat: SavedChat) => {
    setActiveChatId(chat.id)
    setIsDrawerOpen(false)
  }

  const handleDeleteChat = (chatId: string, e?: any) => {
    e?.stopPropagation?.()
    setChats((prev) => {
      const filtered = prev.filter((c) => c.id !== chatId)
      if (filtered.length === 0) {
        const fresh: SavedChat = {
          id: "chat-" + Date.now(),
          title: "Nova conversa",
          messages: [],
          updatedAt: Date.now(),
        }
        setActiveChatId(fresh.id)
        return [fresh]
      }
      if (activeChatId === chatId) {
        setActiveChatId(filtered[0].id)
      }
      return filtered
    })
  }

  async function handleSendMessage(customText?: string) {
    if (!llm || !llm.isReady) return
    const textToSend = (customText || inputMessage).trim()
    if (!textToSend || llm.isGenerating) return

    setInputMessage("")
    const currentMessages = activeChat?.messages || []
    const isFirstMessage = currentMessages.length === 0

    const userMsg: Message = { role: "user", content: textToSend }
    const updatedMessages = [...currentMessages, userMsg]

    const newTitle = isFirstMessage
      ? textToSend.length > 28 ? textToSend.slice(0, 25) + "..." : textToSend
      : activeChat?.title || "Conversa"

    setChats((prev) =>
      prev.map((c) =>
        c.id === activeChatId
          ? { ...c, title: newTitle, messages: updatedMessages, updatedAt: Date.now() }
          : c
      )
    )

    try {
      await llm.sendMessage(textToSend)
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error)
      Alert.alert("Ops!", "Não foi possível enviar a mensagem.")
    }
  }

  useEffect(() => {
    if (!llm || llm.messageHistory.length === 0) return
    setChats((prev) =>
      prev.map((c) =>
        c.id === activeChatId
          ? { ...c, messages: llm.messageHistory, updatedAt: Date.now() }
          : c
      )
    )
  }, [llm?.messageHistory, activeChatId])

  const displayedMessages = activeChat?.messages?.length ? activeChat.messages : llm?.messageHistory || []

  const renderMessage = useCallback((message: Message, index: number) => {
    const isUser = message.role === "user"
    return (
      <View key={index} style={[styles.messageRow, isUser ? styles.userRow : styles.aiRow]}>
        <View style={[styles.bubble, isUser ? styles.userBubble : styles.aiBubble]}>
          {!isUser && <Text style={styles.roleLabel}>Assistente</Text>}
          <Text style={isUser ? styles.userMessageText : styles.messageText}>{message.content}</Text>
        </View>
      </View>
    )
  }, [])

  const promptSuggestions = [
    "Dicas de otimização para React Native",
    "Como o ExecuTorch roda o Llama localmente?",
    "Escreva um hook customizado em TypeScript",
  ]

  // Progresso real do download (0 a 100%)
  const progressPercent = Math.min(100, Math.max(0, Math.round((llm.downloadProgress || 0) * 100)))
  const currentPhase = progressPercent < 30 ? 0 : progressPercent < 70 ? 1 : progressPercent < 95 ? 2 : 3

  // TELA 1: INICIAL SEM MODELO SOLICITADO
  if (!shouldLoadModel) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.readyContainer}>
          <View style={styles.readyIconContainer}>
            <Text style={{ fontSize: 44 }}>🤖</Text>
          </View>
          <Text style={styles.readyTitle}>OnDevice AI</Text>
          <Text style={styles.readySubtext}>
            Sua IA pessoal roda 100% local neste dispositivo.{"\n"}Nenhum dado sai do seu aparelho.
          </Text>

          <View style={styles.readyFeatures}>
            <View style={styles.featureItem}>
              <Text style={{ fontSize: 16, marginRight: 8 }}>🛡️</Text>
              <Text style={styles.featureText}>Privacidade Total</Text>
            </View>
            <View style={styles.featureItem}>
              <Text style={{ fontSize: 16, marginRight: 8 }}>⚡</Text>
              <Text style={styles.featureText}>Llama 3.2 1B SpinQuant</Text>
            </View>
            <View style={styles.featureItem}>
              <Text style={{ fontSize: 16, marginRight: 8 }}>📦</Text>
              <Text style={styles.featureText}>~800MB de download único</Text>
            </View>
          </View>

          <TouchableOpacity onPress={handleStartDownload} style={styles.startButton}>
            <Text style={{ fontSize: 18, marginRight: 6 }}>⬇️</Text>
            <Text style={styles.startButtonText}>Carregar Modelo Local</Text>
          </TouchableOpacity>

          <Text style={styles.readyDisclaimer}>
            O download pode levar alguns minutos dependendo da sua conexão.{"\n"}
            Após a primeira vez, o modelo fica armazenado localmente.
          </Text>
        </View>
      </SafeAreaView>
    )
  }

  // TELA 2: BAIXANDO OU INICIALIZANDO O MODELO
  if (shouldLoadModel && !llm.isReady) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.loadingContainer}>
          <View style={styles.loadingIconContainer}>
            <Text style={{ fontSize: 32 }}>⚡</Text>
          </View>
          <Text style={styles.loadingTitle}>Carregando Modelo Local</Text>
          <Text style={styles.loadingSubtext}>
            {loadingMessages[currentPhase]}
          </Text>

          {/* Barra de Progresso Real */}
          <View style={styles.progressBarContainer}>
            <View style={styles.progressBarTrack}>
              <View style={[styles.progressBarFill, { width: `${Math.max(5, progressPercent)}%` }]} />
            </View>
            <Text style={styles.progressText}>{progressPercent}%</Text>
          </View>

          <View style={styles.loadingCard}>
            <View style={styles.loadingStepItem}>
              <View style={progressPercent > 0 ? styles.loadingStepDot : styles.loadingStepDotPending} />
              <Text style={progressPercent > 0 ? styles.loadingStepActiveText : styles.loadingStepText}>
                Download dos pesos SpinQuant (~800MB)
              </Text>
            </View>
            <View style={styles.loadingStepItem}>
              <View style={progressPercent > 50 ? styles.loadingStepDot : styles.loadingStepDotPending} />
              <Text style={progressPercent > 50 ? styles.loadingStepActiveText : styles.loadingStepText}>
                Verificação de integridade
              </Text>
            </View>
            <View style={styles.loadingStepItem}>
              <View style={progressPercent >= 95 ? styles.loadingStepDot : styles.loadingStepDotPending} />
              <Text style={progressPercent >= 95 ? styles.loadingStepActiveText : styles.loadingStepText}>
                Compilação para NPU/GPU
              </Text>
            </View>
          </View>

          <ActivityIndicator size="large" color="#ffffff" style={{ marginTop: 24 }} />

          {/* Botão Cancelar */}
          <TouchableOpacity onPress={handleCancelDownload} style={styles.cancelButton}>
            <Text style={{ fontSize: 16, marginRight: 6 }}>⏸️</Text>
            <Text style={styles.cancelButtonText}>Pausar Download</Text>
          </TouchableOpacity>

          <View style={styles.loadingBadge}>
            <Text style={{ fontSize: 13, marginRight: 4 }}>🛡️</Text>
            <Text style={styles.loadingBadgeText}>Inferência 100% offline • Sem internet</Text>
          </View>

          {llm.error && (
            <View style={{ marginTop: 16, paddingHorizontal: 16, alignItems: "center" }}>
              <Text style={styles.errorText}>Erro: {String(llm.error?.message || llm.error)}</Text>
              <TouchableOpacity
                onPress={() => {
                  setShouldLoadModel(false)
                  setTimeout(() => setShouldLoadModel(true), 300)
                }}
                style={[styles.startButton, { marginTop: 12, paddingVertical: 10, paddingHorizontal: 20 }]}
              >
                <Text style={styles.startButtonText}>Tentar Novamente</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={styles.container}
        keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <TouchableOpacity onPress={() => setIsDrawerOpen(true)} style={styles.menuButton}>
              <Text style={{ fontSize: 18, color: "#ffffff" }}>☰</Text>
            </TouchableOpacity>
            <Text style={styles.headerTitle} numberOfLines={1}>
              {activeChat?.title || "OnDevice AI"}
            </Text>
          </View>
          <View style={styles.headerRight}>
            <View style={styles.statusBadge}>
              <View style={styles.statusDot} />
              <Text style={styles.statusText}>Local • Llama 3.2</Text>
            </View>
            <TouchableOpacity onPress={handleNewChat} style={styles.iconButton}>
              <Text style={{ fontSize: 20, color: "#ffffff", fontWeight: "bold", lineHeight: 22 }}>＋</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Mensagens */}
        <ScrollView
          style={styles.messagesContainer}
          contentContainerStyle={styles.messagesContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {displayedMessages.length === 0 ? (
            <View style={styles.emptyStateContainer}>
              <View style={styles.emptyStateIconContainer}>
                <Text style={{ fontSize: 32 }}>🤖</Text>
              </View>
              <View style={styles.emptyStateBadgeRow}>
                <View style={styles.emptyStateBadge}><Text style={styles.emptyStateBadgeText}>Llama 3.2 1B</Text></View>
                <View style={styles.emptyStateBadge}><Text style={styles.emptyStateBadgeText}>SpinQuant NPU</Text></View>
                <View style={styles.emptyStateBadge}><Text style={styles.emptyStateBadgeText}>100% Offline</Text></View>
              </View>
              <Text style={styles.emptyStateText}>Pronto para conversar!</Text>
              <Text style={styles.emptyStateSubtext}>
                Sua IA roda diretamente neste dispositivo via ExecuTorch.
              </Text>
              <View style={styles.suggestionsContainer}>
                {promptSuggestions.map((suggestion, idx) => (
                  <TouchableOpacity key={idx} onPress={() => handleSendMessage(suggestion)} style={styles.suggestionItem}>
                    <Text style={styles.suggestionText}>{suggestion}</Text>
                    <Text style={{ fontSize: 14, color: "#737373" }}>➔</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          ) : (
            displayedMessages.map((message, index) => renderMessage(message, index))
          )}

          {llm.isGenerating && (
            <View style={[styles.messageRow, styles.aiRow]}>
              <View style={[styles.bubble, styles.aiBubble]}>
                <Text style={styles.roleLabel}>Assistente</Text>
                <Text style={styles.messageText}>{llm.response || "Pensando..."}</Text>
              </View>
            </View>
          )}
        </ScrollView>

        {/* Input */}
        <View style={styles.inputArea}>
          <View style={styles.inputWrapper}>
            <TextInput
              value={inputMessage}
              onChangeText={setInputMessage}
              placeholder="Pergunte algo para a IA local..."
              placeholderTextColor="#525252"
              style={styles.textInput}
              multiline
              maxLength={500}
              editable={!llm.isGenerating}
              returnKeyType="send"
              onSubmitEditing={() => handleSendMessage()}
            />
            <TouchableOpacity
              onPress={() => handleSendMessage()}
              disabled={!inputMessage.trim() || llm.isGenerating}
              style={[styles.sendButton, (!inputMessage.trim() || llm.isGenerating) && styles.sendButtonDisabled]}
            >
              <Text style={styles.sendButtonText}>{llm.isGenerating ? "..." : "➤"}</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Drawer Modal Nativo */}
        <Modal visible={isDrawerOpen} transparent animationType="slide">
          <TouchableOpacity style={styles.drawerOverlay} activeOpacity={1} onPress={() => setIsDrawerOpen(false)}>
            <View style={styles.drawer} onStartShouldSetResponder={() => true}>
              <View style={styles.drawerHeader}>
                <View style={styles.drawerTitleRow}>
                  <View style={styles.drawerIconBox}>
                    <Text style={{ fontSize: 15 }}>⚡</Text>
                  </View>
                  <Text style={styles.drawerTitle}>Chats Salvos</Text>
                </View>
                <TouchableOpacity onPress={() => setIsDrawerOpen(false)} style={styles.closeButton}>
                  <Text style={{ fontSize: 18, color: "#737373", fontWeight: "bold" }}>✕</Text>
                </TouchableOpacity>
              </View>

              <TouchableOpacity onPress={handleNewChat} style={styles.newChatButton}>
                <Text style={{ fontSize: 16, color: "#000000", fontWeight: "bold", marginRight: 6 }}>＋</Text>
                <Text style={styles.newChatButtonText}>Novo Chat</Text>
              </TouchableOpacity>

              <ScrollView style={styles.chatList} showsVerticalScrollIndicator={false}>
                <Text style={styles.sectionLabel}>Histórico Local</Text>
                {chats.map((chat) => {
                  const isActive = chat.id === activeChatId
                  return (
                    <TouchableOpacity
                      key={chat.id}
                      onPress={() => handleSelectChat(chat)}
                      style={[styles.chatItem, isActive && styles.chatItemActive]}
                    >
                      <View style={styles.chatItemContent}>
                        <View style={styles.chatItemTop}>
                          <Text style={{ fontSize: 14, marginRight: 8 }}>💬</Text>
                          <Text style={[styles.chatItemTitle, isActive && { color: "#ffffff" }]} numberOfLines={1}>
                            {chat.title}
                          </Text>
                        </View>
                        <Text style={styles.chatItemDate}>
                          {chat.messages.length} {chat.messages.length === 1 ? "mensagem" : "mensagens"}
                        </Text>
                      </View>
                      <TouchableOpacity onPress={(e) => handleDeleteChat(chat.id, e)} style={styles.deleteButton}>
                        <Text style={{ fontSize: 14 }}>🗑️</Text>
                      </TouchableOpacity>
                    </TouchableOpacity>
                  )
                })}
              </ScrollView>

              <View style={styles.drawerFooter}>
                <View style={styles.footerRow}>
                  <Text style={styles.drawerFooterText}>Modelo:</Text>
                  <Text style={styles.footerValue}>Llama 3.2 1B</Text>
                </View>
                <View style={styles.footerRow}>
                  <Text style={styles.drawerFooterText}>Inferência:</Text>
                  <Text style={styles.footerValue}>ExecuTorch SpinQuant</Text>
                </View>
                <View style={styles.footerRow}>
                  <Text style={styles.drawerFooterText}>Privacidade:</Text>
                  <Text style={styles.footerValueGreen}>100% On-Device</Text>
                </View>
              </View>
            </View>
          </TouchableOpacity>
        </Modal>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  )
}

registerRootComponent(App)

